# Notes

BMW Web Proxy Munich: 160.46.252.0/25
Why: That range has to be allowed since all requests towards the Azure API are made via the public internet - hence BMW clients will go through the BMW web proxy (Jenkins executing Terraform but also your dev-machine)
MPLS WAN Munich - Azure Amsterdam Primary: 104.209.111.0/24
MPLS WAN Munich - Azure Amsterdam Secondary: 104.209.113.0/24
Why: That's more tricky to explain - see this MSFT docs for details. So there are some requests (i.e. login-requests towards AAD) that apparently travel over our peering connection (express route). Those TCP-packets are NATted and the resulting address lays in the CIDR-range above. Hence, if the respected service should accept these kinds of requests as well you'd have to allow these two CIDR ranges as well.