# VNET Preparation

Provisioning of a VNET that integrates with BMW corp-network is sth. we cannot do using our own IaC scripts due to the network architecture of spoke/hub VNETs (where the spoke VNET is under our control, but _not_ peered with corp-network but the hub-network, which is _not_ under our control, establishes the corp-network connectivity).

Still, when using things like Private Link or Service Endpoints the respective VNET (more specifically a Subnets inside that VNET) has to be explicitly prepared for that. This module serves that purpose - it prepares the Subnet that is supposed to host AKS to allow access to all other supporting services (like ACR, Key-Vault etc.).

We chose a script-based approach to update/adjust the BMW provisioned VNET/Subnets and encapsulate that in a terraform-execution. Hence, the execution is finally part of terraforms state and won't be executed on subsequent `apply`-calls (although it would be idempotent).

## What will be changed

- Disable private endpoint policies so you can add/define private endpoints on/to the given Subnet
- Adding `Microsoft.Storage`, `Microsoft.KeyVault`, `Microsoft.ContainerRegistry` to the list of allowed service endpoints

## Prerequisites
This script assumes you're using terraform environment variables to define service principal credentials (since it re-uses 'em). So make sure you have `ARM_CLIENT_ID`, `ARM_CLIENT_SECRET` and `ARM_TENANT_ID` defined.
