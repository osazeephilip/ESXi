#!/bin/bash

set -eux

##########################################################################################
# Script based approach to update/adjust the BMW-provisioned VNET/Subnets to suite our
# needs. We have to add a few Services as Service-Endpoints in order to secure them.
# Since the BMW-peered VNET isn't part of our provisioning scripts we adjust 'em using a
# bash-script approach.
#
# Input:
# - BMW_VNET_NAME: Name of the VNET
# - BMW_VNET_RESOURCE_GROUP_NAME: Name of the resource-group that hosts this VNET
# - BMW_SUBNET_NAME: Name of the Subnet that should be adjust (that's the Subnet which
#                    finally hosts k8s - hence, access to the respective Services origins
#                    from this subnet)
##########################################################################################

SERVICE_LIST="Microsoft.Storage Microsoft.KeyVault Microsoft.ContainerRegistry"

az login --service-principal -u ${ARM_CLIENT_ID} -p ${ARM_CLIENT_SECRET} --tenant ${ARM_TENANT_ID}

echo "Interacting with azure using the current TF account"
az account show

echo "Disable Private Endpoint Policies for '$BMW_VNET_NAME/$BMW_SUBNET_NAME'"
az network vnet subnet update \
  -g $BMW_VNET_RESOURCE_GROUP_NAME \
  -n $BMW_SUBNET_NAME \
  --vnet-name $BMW_VNET_NAME \
  --disable-private-endpoint-network-policies true

echo "Adding Service-Endpoints for all supporting services to Subnet '$BMW_VNET_NAME/$BMW_SUBNET_NAME'"
az network vnet subnet update \
  -g $BMW_VNET_RESOURCE_GROUP_NAME \
  -n $BMW_SUBNET_NAME \
  --vnet-name $BMW_VNET_NAME \
  --service-endpoints $SERVICE_LIST
