# Postgres Flexible Server (private VNET injection)

This module provisions a [private postgres flexible server][private-access] - for that to work it requires a few pre-requisites that need to be setup before you can actually use this module (since it requires 'em as input-variables):

### Prerequisites

- one [subnet that is delegated][delegation] to Postgres-Flexible server (so `Microsoft.DBforPostgreSQL/flexibleServers`) - since VNETs in our BMW-subscriptions aren't provisioned by the teams this has to be done before.
  ![](./docs/delegation.png)
- we need a private DNS Zone that is linked to our central Hub subscription as well as to the delegated subnet - the concrete means to link to the central VNET are still subject to change - but for now we cannot do that on our own (but only via ITSM-Ticket). Be sure that you stick to the pattern `<can-be-chosen>.private.postgres.database.azure.com` when creating the DNS Zone
  ![](./docs/zone_linking.png)
- a resource group where the DB-server should be provisioned in


### The module supports
- optional (zone-redundant) high-availability (so for DEV-environments you can omit that option - for PROD-environments it's recommended to stick to HA)
- optional [custom maintenance schedule][maintenance] (default is system managed schedule). Again, the idea is to have system-managed schedules for DEV, TEST-environments and only activate custom managed schedules for PROD or close-to-PROD environments. That allows us to have patches applied to DEV, TEST instances 7 days before they get applied to PROD instances - [as suggested by MSFT][maintenance]
- optional provision a number of databases along with the DB-server itself
- optional auto-creation of an admin-password in case you don't provide one(in that case you have to provide key-vault ID where the generated password is stored then).

The module currently is only meant to create new instances - so `create_mode` of `Default` (so recreation based on backups aren't supported).

[private-access]:https://docs.microsoft.com/en-us/azure/postgresql/flexible-server/concepts-networking#private-access-vnet-integration
[delegation]:https://docs.microsoft.com/en-us/azure/postgresql/flexible-server/concepts-networking#virtual-network-concepts
[maintenance]:https://docs.microsoft.com/en-us/azure/postgresql/flexible-server/concepts-maintenance

[//]: # (BEGIN_TF_DOCS)
## Example 1

The following shows a minimalistic example:

```hcl
locals {
  application_id = "N/A"
  env            = "test"
}

########################################################################################################################
# Data gathering block
# - subnet the DB-server should be placed in (has to be delegated to flexible server)
# - private dns zone (linked to the given subnet)
########################################################################################################################
data "azurerm_subnet" "this" {
  name                 = "Subnet-2"
  resource_group_name  = "Group-AMS-VNET-38"
  virtual_network_name = "VNET-bmwFGProd-38"
}
data "azurerm_private_dns_zone" "this" {
  name = "psql-flex-test.private.postgres.database.azure.com"
}

resource "azurerm_resource_group" "this" {
  name     = "rg-postgres-flexible-module-test-2"
  location = "westeurope"
}

###################################################################################################################
# minimal example where we don't define a custome maintenance schedule nor a key-vault integration
###################################################################################################################
module "postgres-flexible-server" {
  source = "../.."

  application_id                         = local.application_id
  env                                    = local.env

  flexible_server_name                   = "psql-flexible-server-test-2"
  flexible_server_resource_group_name    = azurerm_resource_group.this.name
  flexible_server_sku                    = "B_Standard_B1ms"

  # Private DNS Zone that has to be linked to the central Hub-VNET to enable DNS resolution
  flexible_server_private_dns_zone_id    = data.azurerm_private_dns_zone.this.id

  # must be linked to the referenced private dns zone - otherwise terraform/api will complain (and refuse to
  # create resource)
  flexible_server_subnet_id              = data.azurerm_subnet.this.id

  flexible_server_version_admin_login    = "q442185"
  flexible_server_version_admin_password = "Flu88er0815Q2w§dcFtb"
}
```

## Example 2

In constrast, the followin' example shows some non-default settings:

```hcl
locals {
  application_id = "N/A"
  env            = "test"
}

########################################################################################################################
# Data gathering block
# - key-vault to store the generated password in (we don't wanna provide one)
# - subnet the DB-server should be placed in (has to be delegated to flexible server)
# - private dns zone (linked to the given subnet)
########################################################################################################################
data "azurerm_key_vault" "this" {
  name                = "kv-stefan-04"
  resource_group_name = "rg-stefan-common-test"
}
data "azurerm_subnet" "this" {
  name                 = "Subnet-2"
  resource_group_name  = "Group-AMS-VNET-38"
  virtual_network_name = "VNET-bmwFGProd-38"
}
data "azurerm_private_dns_zone" "this" {
  name                 = "psql-flex-test.private.postgres.database.azure.com"
}
data "azurerm_log_analytics_workspace" "this" {
  name                = "log-stefan-52518386cc33022de894"
  resource_group_name = "rg-stefan-common-test"
}


resource "azurerm_resource_group" "this" {
  name     = "rg-postgres-flexible-module-test"
  location = "westeurope"
}
########################################################################################################################
# DB-server with an HA setup and a custom maintenance schedule (like in a PROD environment). We also let the module
# generate a random password that is used for the admin-user and stored in the given key-vault.
# We explicitly set the
# - SKU-size to be General Purpose Standard_D16s_v3 (default is GP_Standard_D4s_v3 default)
# - the storage-size to be 1024 GiB (default is 512 GiB) - see https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server#storage_mb
# - the backup retention to 20 days (default is 7)
########################################################################################################################
module "postgres-flexible-server" {
  source = "../.."

  application_id = local.application_id
  env            = local.env

  flexible_server_name                  = "psql-flexible-server-test"
  flexible_server_resource_group_name   = azurerm_resource_group.this.name
  flexible_server_sku                   = "GP_Standard_D16s_v3"
  flexible_server_storage_mb            = 1048576
  flexible_server_backup_retention_days = 20

  log_analytics_workspace_id            = data.azurerm_log_analytics_workspace.this.id

  # Private DNS Zone that has to be linked to the central Hub-VNET to enable DNS resolution
  flexible_server_private_dns_zone_id = data.azurerm_private_dns_zone.this.id

  # must be linked to the referenced private dns zone - otherwise terraform/api will complain (and refuse to
  # create resource)
  flexible_server_subnet_id = data.azurerm_subnet.this.id


  flexible_server_version_admin_login = "q442185"
  key_vault_id                        = data.azurerm_key_vault.this.id   # but let the module generate/store a new one

  # optional block - if omitted system managed schedule is used
  flexible_server_custom_maintenance_window = {
    day_of_week  = 1
    start_hour   = 20
    start_minute = 00
  }

  flexible_server_high_availability = true

  # initially we provision two databases - one is called 'example-db' the other one 'another-db'
  flexible_server_databases = {
    example-db : {
      collation = "en_US.utf8"
      charset   = "utf8"
    }
    another-db : {
      collation = "en_US.utf8"
      charset   = "utf8"
    }
  }
}
```

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.00 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 2.96.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_diagnostics_microsoft_container_registry"></a> [diagnostics\_microsoft\_container\_registry](#module\_diagnostics\_microsoft\_container\_registry) | ../diagnostics/microsoft_dbforpostgresql_flexibleservers | n/a |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 2.96.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_secret.admin_passwords](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_postgresql_flexible_server.postgresql_server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server) | resource |
| [azurerm_postgresql_flexible_server_database.db](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server_database) | resource |
| [random_password.password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_string.suffix](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_id"></a> [application\_id](#input\_application\_id) | (Required) Application ID as documented in ConnectIT | `string` | n/a | yes |
| <a name="input_diagnostics_enable_log_PostgreSQLLogs"></a> [diagnostics\_enable\_log\_PostgreSQLLogs](#input\_diagnostics\_enable\_log\_PostgreSQLLogs) | Activate Log-integration with log-analytics (requires a `log_analytics_workspace_id`) | `bool` | `true` | no |
| <a name="input_diagnostics_enable_metric_AllMetrics"></a> [diagnostics\_enable\_metric\_AllMetrics](#input\_diagnostics\_enable\_metric\_AllMetrics) | Activate Metric-integration with log-analytics (requires a `log_analytics_workspace_id`) | `bool` | `true` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) Environment/Stage this resource is used in (default: test) | `string` | n/a | yes |
| <a name="input_flexible_server_backup_retention_days"></a> [flexible\_server\_backup\_retention\_days](#input\_flexible\_server\_backup\_retention\_days) | Possible values are between 7 and 35 (see terraform-docs) | `number` | `7` | no |
| <a name="input_flexible_server_custom_maintenance_window"></a> [flexible\_server\_custom\_maintenance\_window](#input\_flexible\_server\_custom\_maintenance\_window) | If present this object will be used to define the custom maintenance schedule. If omitted a system managed schedule is used. | <pre>object({<br>    day_of_week  = number<br>    start_hour   = number<br>    start_minute = number<br>  })</pre> | `null` | no |
| <a name="input_flexible_server_databases"></a> [flexible\_server\_databases](#input\_flexible\_server\_databases) | List of databases to be created in the provisioned DB-server | <pre>map(object({<br>    collation = string<br>    charset   = string<br>  }))</pre> | `{}` | no |
| <a name="input_flexible_server_high_availability"></a> [flexible\_server\_high\_availability](#input\_flexible\_server\_high\_availability) | Whether or not this DB-server should be setup as HA (the zones are random and determined at provisioning time) | `bool` | `false` | no |
| <a name="input_flexible_server_location"></a> [flexible\_server\_location](#input\_flexible\_server\_location) | location the DB-server should be provisioned int | `string` | `"westeurope"` | no |
| <a name="input_flexible_server_name"></a> [flexible\_server\_name](#input\_flexible\_server\_name) | Name of the DB-server to be created | `string` | `"psql-server-test"` | no |
| <a name="input_flexible_server_private_dns_zone_id"></a> [flexible\_server\_private\_dns\_zone\_id](#input\_flexible\_server\_private\_dns\_zone\_id) | (Required) ID of the private DNS zone this DB-server should integrate with (is supposed to be a zone that is linked to the central hub-VNET) | `string` | n/a | yes |
| <a name="input_flexible_server_resource_group_name"></a> [flexible\_server\_resource\_group\_name](#input\_flexible\_server\_resource\_group\_name) | (Required) Resource-Group name this DB-server should be provisioned in (has to be provided and won't be provisioned by this module) | `string` | n/a | yes |
| <a name="input_flexible_server_sku"></a> [flexible\_server\_sku](#input\_flexible\_server\_sku) | SKU of the DB-server to be created (defaults to 'GP\_Standard\_D4s\_v3' - tier + sku (Tier: GeneralPurpose GP, Burstable B, MemoryOptimized MO) | `string` | `"GP_Standard_D4s_v3"` | no |
| <a name="input_flexible_server_storage_mb"></a> [flexible\_server\_storage\_mb](#input\_flexible\_server\_storage\_mb) | The max storage allowed for the DB-server (defaults to 524288) | `number` | `524288` | no |
| <a name="input_flexible_server_subnet_id"></a> [flexible\_server\_subnet\_id](#input\_flexible\_server\_subnet\_id) | (Required) ID of the subnet that was delegated to postgres flexible server | `string` | n/a | yes |
| <a name="input_flexible_server_version"></a> [flexible\_server\_version](#input\_flexible\_server\_version) | Version of the DB-server to be created | `string` | `"13"` | no |
| <a name="input_flexible_server_version_admin_login"></a> [flexible\_server\_version\_admin\_login](#input\_flexible\_server\_version\_admin\_login) | (Required) Username of the admin-user for the DB-server | `string` | n/a | yes |
| <a name="input_flexible_server_version_admin_password"></a> [flexible\_server\_version\_admin\_password](#input\_flexible\_server\_version\_admin\_password) | Password of the admin-user for the DB-server. If that value isn't provided it'll be created during provisioning (and stored in the provided key-vault - whose reference has to be provided instead). | `string` | `null` | no |
| <a name="input_key_vault_id"></a> [key\_vault\_id](#input\_key\_vault\_id) | In case you don't want to provide flexible\_server\_version\_admin\_password via the CLI you can generate a random password during provisioning. That password will be stored in the given key-vault | `string` | `null` | no |
| <a name="input_location"></a> [location](#input\_location) | Region where we provision our cluster (default: West Europe) | `string` | `"West Europe"` | no |
| <a name="input_log_analytics_workspace_id"></a> [log\_analytics\_workspace\_id](#input\_log\_analytics\_workspace\_id) | When you'd like to integrate with Azures log-analytics this setting will enable it and create a respective workspace. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to be added to the provisioned resources (if applicable) | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_flexible_server_admin_password"></a> [flexible\_server\_admin\_password](#output\_flexible\_server\_admin\_password) | n/a |
| <a name="output_flexible_server_administrator_login"></a> [flexible\_server\_administrator\_login](#output\_flexible\_server\_administrator\_login) | n/a |
| <a name="output_flexible_server_fqdn"></a> [flexible\_server\_fqdn](#output\_flexible\_server\_fqdn) | n/a |
| <a name="output_flexible_server_id"></a> [flexible\_server\_id](#output\_flexible\_server\_id) | n/a |
| <a name="output_flexible_server_location"></a> [flexible\_server\_location](#output\_flexible\_server\_location) | n/a |
| <a name="output_flexible_server_name"></a> [flexible\_server\_name](#output\_flexible\_server\_name) | n/a |
| <a name="output_flexible_server_resource_group_name"></a> [flexible\_server\_resource\_group\_name](#output\_flexible\_server\_resource\_group\_name) | n/a |

[//]: # (END_TF_DOCS)
