# LogicApp for ITSM Integration

**Update 28.ß2.2022:** Introduced custom activity-log severity mappings and information extraction for activity-logs

## General Call-Hirarchie

This LogicApp handles the transformation from `azureMonitorCommonAlertSchema` to ITSM ticket (via [AWS ITSM Bridge][itsm_bridge])

```
 Alert -> ActionGroup(s) -> LogicApps -> ITSM Bridge (AWS) -> ITSM Event Management
└─────────────────┬──────────────────┘  └──────┬─────────┘    └─────────┬─────────┘
                  └─> Azure                    └─> AWS                  └─> BMW
```
https://docs.microsoft.com/en-us/azure/azure-monitor/service-limits

### Parameter-Mapping:

For a detailed explanation of each individual ITSM-Bridge property see the respective [JSON-Schema][schema]. Most of those input-properties have to be set during provisioning of the LogicApp (since they are static anyways or cannot be defined on an Azure-Alert - hence, cannot be extracted from the Alert-Payload that calls the LogicApp). The only properties that are filled dynamically on a per-alert basis are:

- `severity`: Each Azure Alert also defines a severity (`data.essentials.severity`) which gets mapped by the LogicApp to a ITSM-Bridge equivalent
  - `Sev0` == `CRITICAL`, `Sev1` == `MAJOR`, `Sev2` == `MINOR`, `Sev3` == `WARNING`, `Sev4` == `OK`<br/>
  `OK` is somehow special as this level doesn't lead to any ITSM-ticket (but actually has the potential of preventing a ticket from being created - see the [ITSM-Bridge documentation][itsm_bridge] for details)
-
- `dd1`: Here the unique AlertId gets filled in - since the `dd`-fields are used for deduplication by the ITSM Event Management **each LogicApp-Alert call will cause a dedicated ticket**.
- `message`: that's by far the most valuable information - it has an upper limit of 2000 chars and we try to fill in as much information as possible.
  - the preamble follows this general pattern: `[alert-description] - [link-to_portal] - [logicApp-workflow-run-id] - [firedDateTime]`
  - if the alert is a Log-Alert we also try to extract log-information that triggered the alert - same is true for Metric-Alerts.

So, an exemplified ITSM-description might look like this:
![ITSM-Ticket result](./images/Alert_1.png)

> **Notice**: only the followin' fields are used for deduplication `contract_id, event_id, mc_host, dd1, dd2, dd3` (see [docs][itsm_bridge])

### LogicApp Flow

The followin' image depicts the LogicApp and the workflow it comprises:
![](./images/LogicApp_2.png)

- When an alert is received the app checks if that was a new alert that was 'Fired' or if that is an update where an existing alert gets 'Resolved'
  - when the alert gets 'Resolved' the Severity is set to 'OK' - calls to the ITSM-Bridge of criticality 'OK' won't create any ITSM-Tickets. Even more, if there was a ticket-creation request before (i.e. due to a 'Fired' alert) and you receive a 'Resolved' alert within the configured `ars_delay_time` the creation of the ITSM-ticket is even prevented.
  - in case of a 'Fired' alert the app maps the given severity to the proper Bridge-Value (see above)
- subsequently, the LogicApp inspect the alert-type and in case of a 'Log'- or a 'Metric'-Alert we try to append further information from the type-specific alert body.

### Severity-Mapping for Activity-Logs

Unlike Metric or Log-Alerts, ActivityLog-Alerts doesn't allow you to set a severity in the respective alert-definition. The [triggered alert though contains a value that defaults to Sev4][default-severity-of-activity-logs] and thus cannot be overwritten - at least not using the alert-definition. In case you'd like to forward these kinds of alerts to ITSM we've introduced a mapping-mechanism that allows you to map the severity of such ActivityLog alerts within the LogApp.

By providing the optional block `activity_log_alert_severity_mappings` you're able to re-map the severity of all alerts triggered by a specific activity-log rule
```hcl
activity_log_alert_severity_mappings = [
  {
    alertRule : "test-me",                // any activity-log alert whose name contains 'test-me' would be ..
    severity : "WARNING"                  // ..  forwarded to ITSM with severity 'WARNING'
  },
  {
    alertRule : "another-test",           // any activity-log alert whose name contains 'another-test' would be ..
    severity : "MAJOR"                    // .. fowarded to ITSM with severity 'MAJOR'
  }
]
```
The `alertRule` executes a `contains`-check - so as soon as your Alert-Rule contains the given string in its name the rule matches and re-maps the default-severity. There is no defined order of those mappings - so don't try to build cascades (so in the example above the result of `another-test-me` is undefined).

[//]: # (BEGIN_TF_DOCS)
## Example usage

The followin' example shows the intended use:

```hcl
variable "logic_app_resource_group_name"                 { default = "rg-schoeffm-common"                       }

variable "dry_run"                                       { default = "true"                                     }
variable "x_api_key"                                     { default = "<fill_in>"                                }
variable "app_id"                                        { default = "<fill_in>"                                }
variable "mcid"                                          { default = "<fill_in>"                                }

variable accessControl_contents_allowedCallerIpAddresses { default = ["160.46.252.0/25"]                        }

variable "logic_app_name"                                { default = "A-la_schoeffm_ITSM"                       }
variable "action_group_name"                             { default = "A-ag-schoeff"                             }
variable "name_suffix"                                   { default = "A"                                        }
variable "email_receiver"                                { default = "Stefan.Schoeffmann@bmw.de"                }

# we retrieve the CIDR-ranges of westeurope action-groups to allow access to only those services
data "azurerm_network_service_tags" "actionGroup" {
  # https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/network_service_tags
  location                                                = "westeurope"
  service                                                 = "ActionGroup"
}


##################################################################################################
# Deploy our Logic-App (via module) that adapts the log-alert schema to the one of AWS'
# ITSM-Bridge
##################################################################################################
module "logicAppITSM" {
  source                                                  = "./../.."
  contract_id                                             = var.mcid
  env                                                     = "test"
  application_id                                          = var.app_id

  resource_group_name                                     = var.logic_app_resource_group_name
  logic_app_name                                          = var.logic_app_name

  action_group_name                                       = var.action_group_name
  action_group_short_name                                 = var.action_group_name
  # optional (but recommended) list of mail-receivers that are notified (just in case
  # the ITSM-chain doesn't work)
  email_receivers                                         = [ var.email_receiver ]

  dry_run                                                 = var.dry_run
  x_api_key                                               = var.x_api_key
  ars_delay_time                                          = 60
  accessControl_triggers_allowedCallerIpAddresses         = data.azurerm_network_service_tags.actionGroup.address_prefixes
  accessControl_contents_allowedCallerIpAddresses         = var.accessControl_contents_allowedCallerIpAddresses
  runtimeConfiguration_lifetime_count                     = 30
}


##################################################################################################
# For later use when defining concrete alerts
##################################################################################################
data "azurerm_logic_app_workflow" "logicApp" {
  resource_group_name                                     = var.logic_app_resource_group_name
  name                                                    = var.logic_app_name
  depends_on                                              = [ module.logicAppITSM ]
}
data "azurerm_monitor_action_group" "this" {
  resource_group_name                                     = var.logic_app_resource_group_name
  name                                                    = var.action_group_name
  depends_on                                              = [ module.logicAppITSM ]
}
```
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.14 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 2.63.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_diagnostics_microsoft_logic_workflows"></a> [diagnostics\_microsoft\_logic\_workflows](#module\_diagnostics\_microsoft\_logic\_workflows) | ../diagnostics/microsoft_logic_workflows | n/a |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 2.63.0 |

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_action_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_action_group) | resource |
| [azurerm_resource_group_template_deployment.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_logic_app_workflow.itsm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/logic_app_workflow) | data source |
| [azurerm_network_service_tags.example](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/network_service_tags) | data source |
| [azurerm_resource_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/resource_group) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_accessControl_contents_allowedCallerIpAddresses"></a> [accessControl\_contents\_allowedCallerIpAddresses](#input\_accessControl\_contents\_allowedCallerIpAddresses) | Defines who is able to access the content of the LogicApp (i.e. the Designer) | `list(string)` | n/a | yes |
| <a name="input_accessControl_triggers_allowedCallerIpAddresses"></a> [accessControl\_triggers\_allowedCallerIpAddresses](#input\_accessControl\_triggers\_allowedCallerIpAddresses) | Defines from where this Logic-App can be triggered | `list(string)` | n/a | yes |
| <a name="input_action_group_name"></a> [action\_group\_name](#input\_action\_group\_name) | The name of the Action Group. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_action_group_short_name"></a> [action\_group\_short\_name](#input\_action\_group\_short\_name) | The short name of the action group. This will be used in SMS messages. | `string` | n/a | yes |
| <a name="input_activity_log_alert_severity_mappings"></a> [activity\_log\_alert\_severity\_mappings](#input\_activity\_log\_alert\_severity\_mappings) | Contains an optional list of activity-log alert and their expected severity in ITSM (due to the fact that activity-log alerts don't allow you to specify a severity explicitly). | <pre>list(object({<br>    alertRule: string<br>    severity: string<br>  }))</pre> | `[]` | no |
| <a name="input_adapter_host"></a> [adapter\_host](#input\_adapter\_host) | Name of the host where the event was created. | `string` | `""` | no |
| <a name="input_application_id"></a> [application\_id](#input\_application\_id) | (Required) BMW valid APPD id, e.g. APPD-12345. Pattern ^APPD-[0-9]{4,7}$ | `string` | n/a | yes |
| <a name="input_ars_delay_time"></a> [ars\_delay\_time](#input\_ars\_delay\_time) | Time in seconds until event will be forwarded to ITSM. Default at IT Event Management is 900 seconds/15 minutes. | `string` | `"900"` | no |
| <a name="input_ars_esc"></a> [ars\_esc](#input\_ars\_esc) | If value is No, the IT Event Management won't create an ITSM ticket. | `string` | `"Yes"` | no |
| <a name="input_bmw_itsm_uri"></a> [bmw\_itsm\_uri](#input\_bmw\_itsm\_uri) | BMW ITSM bridge URI. | `string` | `"https://itsm-gateway.aws.bmw.cloud/v1/itsm"` | no |
| <a name="input_cell"></a> [cell](#input\_cell) | The event management cell which receives the event. The event management forwards events to the ITSM suite. Cell pforwemcell90 is used for production, iforwemcell30 for integration (defaults to 'pforwemcell90' == production) | `string` | `"pforwemcell90"` | no |
| <a name="input_content_type"></a> [content\_type](#input\_content\_type) | BMW ITSM bridge content type (header of invoke). | `string` | `"application/json"` | no |
| <a name="input_contract_id"></a> [contract\_id](#input\_contract\_id) | (Required) The monitoring Contract id from Systems Management Portal (http://systemsmgmt-portal.bmwgroup.net) to assign the event to a target ITSM group. This field will be used for the deduplication check. | `string` | n/a | yes |
| <a name="input_diagnostics_enable_log_WorkflowRuntime"></a> [diagnostics\_enable\_log\_WorkflowRuntime](#input\_diagnostics\_enable\_log\_WorkflowRuntime) | Enable diagnostics for log 'WorkflowRuntime'. Defaults to 'true'. | `bool` | `true` | no |
| <a name="input_diagnostics_enable_metric_AllMetrics"></a> [diagnostics\_enable\_metric\_AllMetrics](#input\_diagnostics\_enable\_metric\_AllMetrics) | Enable diagnostics for metric 'AllMetrics'. Defaults to 'true'. | `bool` | `true` | no |
| <a name="input_diagnostics_log_analytics_workspace_id"></a> [diagnostics\_log\_analytics\_workspace\_id](#input\_diagnostics\_log\_analytics\_workspace\_id) | Enable diagnostics logging by providing a LogAnalytics workspace id. Defaults to 'null'. | `string` | `null` | no |
| <a name="input_dry_run"></a> [dry\_run](#input\_dry\_run) | If set to true, Lambda will only run the parameter validation but won't connect to the on premise IT Event Management. | `string` | `"true"` | no |
| <a name="input_email_receivers"></a> [email\_receivers](#input\_email\_receivers) | A list of email-receivers that also get notified via eMail | `list(string)` | `[]` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) Environment/Stage this resource is used in (default: test) | `string` | n/a | yes |
| <a name="input_event_class"></a> [event\_class](#input\_event\_class) | This is a constant value. | `string` | `"BMW_AWS"` | no |
| <a name="input_event_id"></a> [event\_id](#input\_event\_id) | Unique event number (5-digits) within the related MCID from Systems Management Portal. This field will be used for the deduplication check. | `string` | `"80000"` | no |
| <a name="input_event_source"></a> [event\_source](#input\_event\_source) | n/a | `string` | `"Amazon_WS"` | no |
| <a name="input_has_impact"></a> [has\_impact](#input\_has\_impact) | Additional information which will be copied in to the the work info field. | `string` | `"Yes"` | no |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | `"westeurope"` | no |
| <a name="input_logic_app_name"></a> [logic\_app\_name](#input\_logic\_app\_name) | (Required) Name of the logicApp | `string` | n/a | yes |
| <a name="input_mc_host"></a> [mc\_host](#input\_mc\_host) | For example a hostname which is used for deduplication. This field will be used for the deduplication check. | `string` | `"AWS_undefined"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | (Required) Name of the resource group (has to exist already - won't be provisioned) | `string` | n/a | yes |
| <a name="input_runtimeConfiguration_lifetime_count"></a> [runtimeConfiguration\_lifetime\_count](#input\_runtimeConfiguration\_lifetime\_count) | Number of days the execution history is preserved (everything older than that will be deleted). | `number` | `30` | no |
| <a name="input_server_loc"></a> [server\_loc](#input\_server\_loc) | Location of the server or service, for example the Azure region westeurope | `string` | `"westeurope"` | no |
| <a name="input_sub_origin"></a> [sub\_origin](#input\_sub\_origin) | This value is only visible to admins of the event management system and won't be forwarded to the ITSM suite. This value is used for event assignments and must be a valid 12 char AWS account id. | `string` | `"123456789000"` | no |
| <a name="input_sub_source"></a> [sub\_source](#input\_sub\_source) | Valid AWS ARN (Amazon Resource Name), mandatory for licensing reasons (for example: arn:aws:ec2:us-east-1:123456789012:instance/i-abcdefghi12345678). | `string` | `"arn:aws:ec2:us-west-1:123456789012:instance/i-abcdefghi12777888"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to be added to the provisioned resources (if applicable) | `map(string)` | `{}` | no |
| <a name="input_x_api_key"></a> [x\_api\_key](#input\_x\_api\_key) | (Required) Your BMW ITSM bridge x-api-key (header of invocation). | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_action_group_id"></a> [action\_group\_id](#output\_action\_group\_id) | n/a |
| <a name="output_address_prefixes_ActionGroup"></a> [address\_prefixes\_ActionGroup](#output\_address\_prefixes\_ActionGroup) | n/a |
| <a name="output_logic_app_callbackurl"></a> [logic\_app\_callbackurl](#output\_logic\_app\_callbackurl) | n/a |

[//]: # (END_TF_DOCS)

[itsm_bridge]:https://atc.bmwgroup.net/confluence/display/DEVOPSPF/AWS+ITSM+Bridge
[schema]:https://atc.bmwgroup.net/bitbucket/projects/FPCBMW/repos/aws-itsm-api/raw/src/create_itsm_ticket/itsm_schema.json?at=refs%2Fheads%2Fmaster
[default-severity-of-activity-logs]:https://docs.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-activity-log
[example-alerts]:https://docs.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-common-schema-test-action-definitions
