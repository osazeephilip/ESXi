#!/bin/bash

# sample script
# - to upload a couple of files in short time
# - to regenerate the secondary key
# to trigger alerts



uuid=$(uuidgen)

for i in {1..20}
do
   az storage blob upload --container-name aaa       \
                          --file ./test.sh           \
                          --name "test-$uuid-$i.sh"  \
                          --account-name stschoeffm \
                          --only-show-errors &
done

wait

az storage account keys renew --resource-group rg-schoeffm-common --account-name stschoeffm --key secondary
 