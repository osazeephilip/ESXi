#!/bin/bash

# example usage: ./callabackUrl.sh  "fca564c9-6b4e-4ece-87db-49cba4e01a9f" "rg-fleckert-common" "20-la_fleckert_ITSM" "myFile.txt"
# see https://docs.microsoft.com/en-us/rest/api/logic/workflows/list-callback-url#workflowtriggercallbackurl
# preconditions:
# - Azure CLI is installed
# - Azure CLI is logged in
# - jq is installed

subscriptionId=$1    #"fca564c9-6b4e-4ece-87db-49cba4e01a9f"
resourceGroupName=$2 # "rg-fleckert-common"
workflowName=$3      # "20-la_fleckert_ITSM"
fileName=$4

access_token=$(az account get-access-token --resource="https://management.azure.com" --query accessToken --output tsv)

callbackUrl=$(curl --request POST \
                   --silent \
                   --header "Authorization: Bearer ${access_token}" \
                   --header "Content-Type: application/json" \
                   --data '{  "keyType": "Primary" }' \
                   "https://management.azure.com/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.Logic/workflows/${workflowName}/listCallbackUrl?api-version=2016-06-01" \
              | \
              jq -r ".value")

     
echo $callbackUrl > "$4"