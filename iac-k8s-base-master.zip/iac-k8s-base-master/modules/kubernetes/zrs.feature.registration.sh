#!/bin/bash

set -eux

##############################################################################################################
# In order to use ZRS-disks in AKS we have to register SsdZrsManagedDisks as well
# propagate the change by calling 'provider register'
# If that feature/provider is already registred that call has no effect
##############################################################################################################
az feature register --name SsdZrsManagedDisks --namespace Microsoft.Compute
az feature list -o table --query "[?contains(name, 'Microsoft.Compute/SsdZrsManagedDisks')].{Name:name,State:properties.state}"
az provider register --namespace Microsoft.Compute
