# Subscription Alerts

Take this module as an opinionated starting point that should/could be adjusted to your project specific requirements and needs. It meant to give you a solid set of alerts that provide valuable insights into the health and the status of your services and resources - most of the time the alerts will just send mails (to be then inspected and evaluated by your DevOps team - after that you might change or adjust those definitions to get actual tickets instead of mails).

First, some general information about 'ActivityLog'-alerts (which is the underpinning data-source of 'ServiceHealth' as well as 'ResourceHealth'):

## [Azure Service Health](https://docs.microsoft.com/en-us/azure/service-health/overview)

Azure offers a suite of experiences to keep you informed about the health of your cloud resources. This information includes current and upcoming issues such as service impacting events, planned maintenance, and other changes that may affect your availability.

[Azure Service Health](https://docs.microsoft.com/en-us/azure/service-health/overview) = [Azure status](https://status.azure.com/en-us/status) + [Service health](https://docs.microsoft.com/en-us/azure/service-health/service-health-overview) + [Resource health](https://docs.microsoft.com/en-us/azure/service-health/resource-health-overview)

### [Azure status](https://status.azure.com/en-us/status)
The health of all Azure services across all Azure regions

### [Service health](https://docs.microsoft.com/en-us/azure/service-health/service-health-overview)
The health of the Azure services and regions you're using

four types of health events that may impact your resources:
- **Service issues**: Azure service issues right now.
- **Planned maintenance**: Upcoming maintenance for services in the future that may affect the availability.
- **Health advisories**: Changes in Azure services that require your attention. Examples include deprecation of Azure features or upgrade requirements .
- **Security advisories**: Security related notifications or violations that may affect the availability of your Azure services.

### [Resource health](https://docs.microsoft.com/en-us/azure/service-health/resource-health-overview)
The health of individual cloud resources - example: a specific virtual machine instance, a database instance or a Service App.

------

||Scope|Service|
|-|-|-|
|[Azure status   ](https://status.azure.com/en-us/status                                         )|all Azure regions| all Azure services|
|[Service health ](https://docs.microsoft.com/en-us/azure/service-health/service-health-overview )|my regions       |my services|
|[Resource health](https://docs.microsoft.com/en-us/azure/service-health/resource-health-overview)|region           |my instance|

------

## Implementation details

The module creates a bunch of alerts - since these alerts need the integration with at least one action-group to be of any use this module expects you have at least two action groups in existence
- email: use this Action Group as the default. Emails don't _wake somebody up at night_ but become useless if the recipients create an email rule that sends the emails to the _spam_ folder
- itsm: use this Action Group to create an ITSM ticket<br/>

```
Logs -> Alert -1:n-> Action Group
```

The module uses ARM templates to overcome limitations in Terraform alert definitions (you can use the Azure Portal to create the alerts, export 'em subsequently to be embedded within your Terraform script.)

### Reduce unnecessary creation of ITSM-tickets

Only a small subset of all available activity-log entries would qualify for an ITSM-ticket creation. Things like recommendations or maintenance information are things that are good to know - but don't require an ITSM-ticket.

In our module we only create ITSM-tickets for ServiceHealth-entries of event-type Incident. To prevent those alerts from being fired for every single update of one specific incident we:

1. ingest the ActivityLog into a LogAnalytics workspace (that's [supposed to be cost-neutral](https://docs.microsoft.com/en-us/azure/azure-monitor/logs/manage-cost-storage)))
   ![ActivityLog ingestion to LogAnalytics](./diagnostic_settings.png)
2define an aggregation-query that only selects the first entry of an Incident (identified by 'trackingId') of status 'Active'
3use that query to define an ordinary (scheduled-)log-alert that is executed every 5 minutes
   - the time-window this query takes into account is the maximum possible to 2 days - so the aggregation (and thus the deduplication) will act on that time frame

Step one is sth. you have to do once for your subscription - all subsequent steps are tackled by the alert-definition inside this module.

### Query-Logs

In order to get a feeling about what you can expect you could either check the "ActivityLog" blade in Azure ... or use the API in combination with some `jq` and `grep`-foo to get an impression.

In `./examples/queryLogs.sh` you can find a few query that request only ResourceHealth-entries etc.

```bash
subscriptionId="fca564c9-6b4e-4ece-87db-49cba4e01a9f"
startDate="2021-09-01"
category="ServiceHealth"
uri="https://management.azure.com/subscriptions/$subscriptionId/providers/microsoft.insights/eventtypes/management/values?api-version=2017-03-01-preview&%24filter=eventTimestamp%20ge%20%27${startDate}T00%3A00%3A00Z%27%20and%20categories%20eq%20%27$category%27%20"

az rest --uri $uri
```

[//]: # (BEGIN_TF_DOCS)
## Requirements

No requirements.

## Modules

No modules.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_activity_log_alert.Administrative-Failed](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_activity_log_alert) | resource |
| [azurerm_monitor_activity_log_alert.Autoscale-Failed](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_activity_log_alert) | resource |
| [azurerm_monitor_activity_log_alert.ServiceHealth-All](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_activity_log_alert) | resource |
| [azurerm_monitor_scheduled_query_rules_alert.ServiceHealth-Incident-Active-First-Event](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_scheduled_query_rules_alert) | resource |
| [azurerm_resource_group_template_deployment.Policy-CriticalError](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_resource_group_template_deployment.ResourceHealth-Degraded](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_resource_group_template_deployment.ResourceHealth-Unavailable](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_resource_group_template_deployment.Security-CriticalErrorWarn](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_log_analytics_workspace.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/log_analytics_workspace) | data source |
| [azurerm_monitor_action_group.email](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/monitor_action_group) | data source |
| [azurerm_monitor_action_group.itsm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/monitor_action_group) | data source |
| [azurerm_subscription.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_action_group_email_name"></a> [action\_group\_email\_name](#input\_action\_group\_email\_name) | The name of an existing ActionGroup that will be used for email notifications. | `string` | n/a | yes |
| <a name="input_action_group_email_resource_group_name"></a> [action\_group\_email\_resource\_group\_name](#input\_action\_group\_email\_resource\_group\_name) | The resource group name of an existing ActionGroup that will be used for email notifications. | `string` | n/a | yes |
| <a name="input_action_group_itsm_name"></a> [action\_group\_itsm\_name](#input\_action\_group\_itsm\_name) | The name of an existing ActionGroup that will be used for ITSM notifications. | `string` | n/a | yes |
| <a name="input_action_group_itsm_resource_group_name"></a> [action\_group\_itsm\_resource\_group\_name](#input\_action\_group\_itsm\_resource\_group\_name) | The resource group name of an existing ActionGroup that will be used for ITSM notifications. | `string` | n/a | yes |
| <a name="input_alert_resource_group_name"></a> [alert\_resource\_group\_name](#input\_alert\_resource\_group\_name) | The to be created alerts will be added to this existing resource group. To see the alerts in the Azure Portal, enable 'Show hidden types' within the resource group overview. | `string` | n/a | yes |
| <a name="input_locations"></a> [locations](#input\_locations) | Alert definitions that use the 'location' filter are respecting this setting. | `list(string)` | n/a | yes |
| <a name="input_log_analytics_workspace_name"></a> [log\_analytics\_workspace\_name](#input\_log\_analytics\_workspace\_name) | The name of an existing log analytics workspace that is linked via azurerm\_monitor\_diagnostic\_setting to the subscription. | `string` | n/a | yes |
| <a name="input_log_analytics_workspace_resource_group_name"></a> [log\_analytics\_workspace\_resource\_group\_name](#input\_log\_analytics\_workspace\_resource\_group\_name) | The resource group name of an exisitng log analytics workspace that is linked via azurerm\_monitor\_diagnostic\_setting to the subscription. | `string` | n/a | yes |
| <a name="input_prefix"></a> [prefix](#input\_prefix) | This prefix will be used as a prefix to the Alert Definition Name. Format: {Prefix}{SubscriptionName}{AlertName} | `string` | `""` | no |
| <a name="input_subscription_id"></a> [subscription\_id](#input\_subscription\_id) | The to be created alerts will be scoped to this Azure subscription. | `string` | n/a | yes |

## Outputs

No outputs.

[//]: # (END_TF_DOCS)
