# subscriptionId="78075a1e-37e3-4210-a0b4-ce4465723e4a"
subscriptionId="fca564c9-6b4e-4ece-87db-49cba4e01a9f"
startDate="2021-09-01"

# see https://docs.microsoft.com/en-us/rest/api/monitor/activity-logs/list

# -------------------------------------------------------------
category="Recommendation"
uri="https://management.azure.com/subscriptions/$subscriptionId/providers/microsoft.insights/eventtypes/management/values?api-version=2017-03-01-preview&%24filter=eventTimestamp%20ge%20%27${startDate}T00%3A00%3A00Z%27%20and%20categories%20eq%20%27$category%27%20"

az rest --uri $uri \
| jq "[ .value[] | .properties.recommendationName + \" | \" + .resourceId + \" | \" + .eventTimestamp ] | sort" \
| jq ".[]" \
> $subscriptionId-$category.csv

# -------------------------------------------------------------
category="Security"
uri="https://management.azure.com/subscriptions/$subscriptionId/providers/microsoft.insights/eventtypes/management/values?api-version=2017-03-01-preview&%24filter=eventTimestamp%20ge%20%27${startDate}T00%3A00%3A00Z%27%20and%20categories%20eq%20%27$category%27%20"

az rest --uri $uri \
| jq "[ .value[] | .eventTimestamp + \" | \" + .level + \" | \" + .status.value + \" | \" + .properties.compromisedEntity + \" | \" + .description] | sort | reverse" \
| jq ".[]" \
> $subscriptionId-$category.csv

# -------------------------------------------------------------
category="ServiceHealth"
uri="https://management.azure.com/subscriptions/$subscriptionId/providers/microsoft.insights/eventtypes/management/values?api-version=2017-03-01-preview&%24filter=eventTimestamp%20ge%20%27${startDate}T00%3A00%3A00Z%27%20and%20categories%20eq%20%27$category%27%20"

az rest --uri $uri \
| jq "[ .value[] | .eventTimestamp  + \" | \" + .properties.trackingId  + \" | \" + .level + \" | \" + .properties.incidentType + \" | \" + .properties.region+ \" | \" +  .properties.service+ \" | \" +  .properties.stage+ \" | \" +  .description] | sort | reverse" \
| jq ".[]" \
> $subscriptionId-$category.csv

# -------------------------------------------------------------
category="Administrative"
uri="https://management.azure.com/subscriptions/$subscriptionId/providers/microsoft.insights/eventtypes/management/values?api-version=2017-03-01-preview&%24filter=eventTimestamp%20ge%20%27${startDate}T00%3A00%3A00Z%27%20and%20categories%20eq%20%27$category%27%20"

az rest --uri $uri \
| jq "[ .value[] | .eventTimestamp  + \" | \" + .operationName.localizedValue  + \" | \" + .level + \" | \" + .status.value + \" | \" +  .description ] | sort | reverse" \
| jq ".[]" \
> $subscriptionId-$category.csv

# -------------------------------------------------------------
category="ResourceHealth"
uri="https://management.azure.com/subscriptions/$subscriptionId/providers/microsoft.insights/eventtypes/management/values?api-version=2017-03-01-preview&%24filter=eventTimestamp%20ge%20%27${startDate}T00%3A00%3A00Z%27%20and%20categories%20eq%20%27$category%27%20"

az rest --uri $uri \
| jq "[ .value[] | .eventTimestamp  + \" | \" + .operationName.localizedValue  + \" | \" + .level + \" | \" + .status.value + \" | \" +  .description ] | sort | reverse" \
| jq ".[]" \
> $subscriptionId-$category.csv
