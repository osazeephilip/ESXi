# App Gateway

<!-- vim-markdown-toc GFM -->
* [Setup](#setup)
* [ToDos](#todos)
* [Things to be aware of](#things-to-be-aware-of)
    * [Terraform things to be aware of](#terraform-things-to-be-aware-of)
    * [AKS things to be aware of](#aks-things-to-be-aware-of)
<!-- vim-markdown-toc -->

We introduced an [application gateway][appgw] in front of our k8s clusters to support a seamless Blue/Green-upgrade experience and still have one stable IP/entrypoint for all calling clients.

![App Gateway Setup for Blue/Green Upgrade](./../../docs/application_gateway.png)

When getting to know application gateway [this documentation page][components] gives a good overview of the moving parts involved.

## Setup
- the gateway lives in its own resource group since it basically will outlive the lifespan of an AKS cluster
  - it has to be provisioned separately with its own terraform state (it shouldn't be part of the k8s cluster state)
  - maybe it's worth to put the application gateway into the _central services_ (along with Key-Vault, ACR, DES etc.)
    - ... and still, the gateway has to be integrated with the AKS provisioning since the backend-pool IPs are only known once there's an ingress deployed in AKS (which only comes to life once AKS is provisioned)

## ToDos
In case you'd like to use an App Gateway in front of your AKS you should also think about the followin' topics (that aren't related to my blue/gree PoC and thus not included in my setup):
- [ ] SSL-termination and re-encryption of downstream traffic
- [ ] Key-Vault integration (probably via managed identity)
- [ ] Log Analytics integration

## Things to be aware of
- This setup was introduced for a Blue/Green upgrade proof-of-concept. So for a valid setup the application gateway still misses some important things (see ToDos section)
- All `v2`-SKUs require a public IP to be defined/assigned. Only `v1`-SKUs have the ability to have only a private IP attached.
  - _**Update 28.04.2021**: Recommendation from MSFT (Uwe Hoffmann) is to use `v2`-SKUs and don't assign a listener to the public IP. Product teams are working on that topic already._
- you have to explicitly activate connection draining - since for our use-case this is one of the most important features, we activate that features for all listeners and don't offer a (terraform-)variable/setting to change that.

### Terraform things to be aware of
- in order to have a public (see above) as well as a private IP you have to define two independent, non-overlapping blocks `frontend_ip_configuration`
  - non-overlapping: one defines the public - the other one defines the private IP 
    - the props of that block are either relevant for public or private - not both
    - putting both into one block won't work
  
### AKS things to be aware of
- when deploying a green cluster, which is basically a copy of the original one, you have to make sure to change a few things to keep 'em running (especially when you're using `kubenet`)
  - Pod CIDR ranges: They mustn't overlap - otherwise both cluster will define UDRs that are competing with each other
  - DNS prefixes: They have to be different - otherwise only one cluster will create UDRs at all (the other one doesn't have UDRs and thus isn't accessible)
  - I put a [more detailed explanation of what's goin' on in confluence][several_aks_in_one_vnet]

[components]:https://docs.microsoft.com/en-us/azure/application-gateway/application-gateway-components
[appgw]:https://docs.microsoft.com/en-us/azure/application-gateway/overview
[several_aks_in_one_vnet]:https://atc.bmwgroup.net/confluence/display/INNOBOM/Hosting+several+AKS+in+one+VNET
