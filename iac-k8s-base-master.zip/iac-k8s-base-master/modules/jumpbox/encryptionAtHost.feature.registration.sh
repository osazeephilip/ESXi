#!/bin/bash

set -eux

##############################################################################################################
# In order to use encrypt tmp-folders and storage-communication we have to register EncryptionAtHost first
# propagate the change by calling 'provider register'
# If that feature/provider is already registered that call has no effect
##############################################################################################################
az feature register --namespace "Microsoft.Compute" --name "EncryptionAtHost"
az feature list -o table --query "[?contains(name, 'Microsoft.Compute/EncryptionAtHost')].{Name:name,State:properties.state}"
az provider register --namespace Microsoft.Compute
