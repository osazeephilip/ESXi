#!/bin/bash
set -x

AZURE_WEB_PROXY=http://10.6.156.132:8080
NO_PROXY_LIST='localhost,127.0.0.1,.bmwgroup.net,azure.com,blob.core.windows.net,azmk8s.io'
KUBERNETES_VERSION="v1.19.3"
HELM_VERSION="v3.4.2"
TERRAFORM_VERSION="0.15.1"

function install_tooling() {
  sudo apt update && \
    sudo apt install -y vim tree jq zip ca-certificates curl apt-transport-https lsb-release gnupg docker.io

  sudo groupadd docker

  curl -sL https://packages.microsoft.com/keys/microsoft.asc |
      gpg --dearmor |
      sudo tee /etc/apt/trusted.gpg.d/microsoft.gpg > /dev/null

  AZ_REPO=$(lsb_release -cs)
  echo "deb [arch=amd64] https://packages.microsoft.com/repos/azure-cli/ $AZ_REPO main" |
      sudo tee /etc/apt/sources.list.d/azure-cli.list

  sudo apt update && sudo apt install -y azure-cli

  curl -v -fsSL -o get_helm.sh https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3 && \
      chmod 700 get_helm.sh && \
    sudo ./get_helm.sh -v $HELM_VERSION

  curl -v -LO https://storage.googleapis.com/kubernetes-release/release/$KUBERNETES_VERSION/bin/linux/amd64/kubectl && \
    chmod +x ./kubectl && \
    sudo mv ./kubectl /usr/local/bin/kubectl

  curl -fsSL -o terraform_$${TERRAFORM_VERSION}_linux_amd64.zip https://releases.hashicorp.com/terraform/$${TERRAFORM_VERSION}/terraform_$${TERRAFORM_VERSION}_linux_amd64.zip && \
    sudo unzip terraform_$${TERRAFORM_VERSION}_linux_amd64.zip -d /usr/bin
}

# Configures the Azure Web-Proxy (for the current shell as well as in the /etc/environment
function setup_http_proxy() {
  export HTTP_PROXY=$AZURE_WEB_PROXY
  export HTTPS_PROXY=$AZURE_WEB_PROXY
  export NO_PROXY=localhost,127.0.0.1,.bmwgroup.net

  sudo bash -c "echo 'HTTP_PROXY=$AZURE_WEB_PROXY' >> /etc/environment"
  sudo bash -c "echo 'HTTPS_PROXY=$AZURE_WEB_PROXY' >> /etc/environment"
  sudo bash -c "echo 'NO_PROXY=$NO_PROXY_LIST' >> /etc/environment"
}
function user_exists() { id "$1" &>/dev/null; }
function setup_users() {
  %{ for idx, user in authorized_users ~}
  if ! user_exists "${user}";then
    sudo useradd -m -d /home/${user} -s /bin/bash ${user} -K UMASK=026 -G docker
    mkdir -p /home/${user}/.ssh
  fi
  echo '${authorized_keys[idx]}' > /home/${user}/.ssh/authorized_keys
  chown -R ${user}:${user} /home/${user}/.ssh

  %{ endfor ~}
}

# set the Azure web-proxy so you're able to reach out to the public internet
setup_http_proxy

# Install a few tools - just in case you'd like to do sth. right on this machine (azure CLI, kubectl, jq ...)
install_tooling

# initialize dedicated users that should have the right to connect to that VM
# (these users don't have sudo-rights!)
setup_users
