# SSH Jump-Box (Linux VM)

Private IP addresses from BMW peered VNETs are directly resolvable from within the BMW corporate network. Unfortunately, those (private) IP addresses can cause trouble for our external partners since they are ambiguous from _their_ corp-network perspective.

The official solution to this problem are VDIs (Virtual Desktop Infrastructure) - so, if you can get VDIs for all your partners and if all use-cases can be accomplished via VDIs you should go for that solution.

Having said that, a (from a network perspective) tolerated alternative are [NATed][NATting] addresses.
Via a [TUFIN][tufin]-request one can ask for a public resolvable IP that gets translated to the private address (mentioned in the request). Since that has to be done on a per-IP level that doesn't scale well. Hence, the idea of this module is to create one entrypoint in form of a VM jump-box - whose private IP get NAT'ed and thus can be accessed by external partners. Via SSH you can subsequently [tunnel ports][port_forwarding] to further services that live in your VNET.

```bash
# Connecting to the JumpBox (assuming you are in Corp-Network - so you can use the private address
# 10.9.82.180) and tunnel all traffic from/to localhost:8080 to stefan.bomk8stest.azure.cloud.bmw:80
# (which happens to be the DNS name of the L4LB of the k8s ingress controller).
$> ssh schoeffm@10.9.82.180 -L 8080:stefan.bomk8stest.azure.cloud.bmw:80 -i ~/.ssh/id_rsa_azure

# Now whenever you access localhost:8080 your request will end up on the k8s-cluster
$> curl -H'Host:httpbin.stefan.bomk8stest.azure.cloud.bmw' http://localhost:8080

# to be usable in your browser you could also add an entry in your /etc/hosts file
$> cat /etc/hosts
127.0.0.1   localhost httpbin.stefan.bomk8stest.azure.cloud.bmw
...

# now that works as w ell
$> curl --noproxy httpbin.stefan.bomk8stest.azure.cloud.bmw http://httpbin.stefan.bomk8stest.azure.cloud.bmw:8080
```

![Setup and basic concept](./docs/jump_box.png)

This repo contains a VM-provisioning configuration that is meant to act as SSH-JumpBox (**_NATing has to be done by you via [TUFIN][tufin], though_**).

[//]: # (BEGIN_TF_DOCS)
## Example usage

The followin' example shows the intended use:

```hcl
##############################################################################
# Gather some data to services we'd like to integrate with
##############################################################################
data "azurerm_disk_encryption_set" "des" {
  name                              = "des-stefan-test"
  resource_group_name               = "rg-stefan-common-test"
}

##############################################################################
# finally, provision the VM
##############################################################################
module "jump_box" {
  source                            = "../.."

  name                              = "JumpBox"
  resource_group_name               = "rg-jump-box"
  application_id                    = "N/A"           # your AppID goes in here
  env                               = "dev"

  # we need an existing DES to encrypt our OS-disk (so that security center is quiet)
  des_id                            = data.azurerm_disk_encryption_set.des.id

  authorized_users                  = {                                 # dictionary: 'user' <-> 'key'
    schoeffm                        = file("./ssh/id_rsa_schoeffm.pub")
    magana                          = file("./ssh/id_rsa_magana.pub")
  }

  admin                             = {
    username                        = "adminuser"
    public_key                      = file("~/.ssh/id_rsa.pub")         # key for the admin user
  }

  network_integration               = {
    resource_group_name             = "Group-AMS-VNET-82"
    virtual_network_name            = "VNET-bmwFGProd-82"
    subnet_name                     = "Subnet-2"
    private_ip_address_to_allocate  = "10.9.82.180"                     # pick that one manually
  }
}

```

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.15 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 2.63.0 |

## Modules

No modules.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 2.63.0 |

## Resources

| Name | Type |
|------|------|
| [azurerm_linux_virtual_machine.jump_box](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_virtual_machine) | resource |
| [azurerm_network_interface.nic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_security_group_association.example](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_security_group.nsg_jump_box](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_resource_group.rg_jump_box](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_virtual_machine_extension.guest_config](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.provisioning](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_subnet.bmw_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_admin"></a> [admin](#input\_admin) | (Required) The credentials for the admin account (yes, we don't accept a password - only public key) | <pre>object({<br>    username                        = string<br>    public_key                      = string<br>  })</pre> | n/a | yes |
| <a name="input_application_id"></a> [application\_id](#input\_application\_id) | (Required) Application ID as documented in ConnectIT | `string` | n/a | yes |
| <a name="input_authorized_users"></a> [authorized\_users](#input\_authorized\_users) | A map of { username = file('public\_ssh\_key) } for all users that should be created on that VM | `map(string)` | `{}` | no |
| <a name="input_des_id"></a> [des\_id](#input\_des\_id) | (Mandatory) In order to encrypt the OS-disk we need a Disk-Encryption-Set to be used. | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) Environment/Stage this resource is used in (default: test) | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | Name of the VM that's supposed to act as SSH-JumbBox | `string` | `"JumbBox"` | no |
| <a name="input_network_integration"></a> [network\_integration](#input\_network\_integration) | References the subnet this JumpBox should be placed in (and you should define a fixed IP from that subnet to be assigned to the VM). | <pre>object({<br>    resource_group_name             = string<br>    virtual_network_name            = string<br>    subnet_name                     = string<br>    private_ip_address_to_allocate  = string<br>  })</pre> | n/a | yes |
| <a name="input_nic-name"></a> [nic-name](#input\_nic-name) | Name of the NIC (default: nic-jump-box) | `string` | `"nic-jump-box"` | no |
| <a name="input_resource_group_location"></a> [resource\_group\_location](#input\_resource\_group\_location) | Region/Location the RG should be provisioned in | `string` | `"westeurope"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | ResourceGroup the VM should be placed in | `string` | `"rg-jump-box"` | no |
| <a name="input_size"></a> [size](#input\_size) | Size of the VM to be provisioned (default: Standard\_A1\_v2) | `string` | `"Standard_A1_v2"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to be added to the provisioned resources (if applicable) | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_jump_host_id"></a> [jump\_host\_id](#output\_jump\_host\_id) | n/a |
| <a name="output_nic_ip"></a> [nic\_ip](#output\_nic\_ip) | n/a |
| <a name="output_resource_group_id"></a> [resource\_group\_id](#output\_resource\_group\_id) | n/a |

[//]: # (END_TF_DOCS)


[NATting]:https://en.wikipedia.org/wiki/Network_address_translation
[port_forwarding]:https://www.ssh.com/academy/ssh/tunneling/example
[tufin]:https://tufin.bmwgroup.net/ps/wizard
