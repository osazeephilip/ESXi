# Disk Encryption Set

This module provisions a [Disk-Encryption-Set][des] which can be used in conjunction with AKS-`StorageClasses` to provide persistent volumes that are based on encrypted disks storage.

## Setup

A DES uses/needs a (i.e. RSA) key to do its job. In this module that key is stored in an [Azure Key Vault][key-vault] 
- provisioning a key-vault is **not** part of this module - but what this module does, it leverages an existing key-vault and generates an RSA-key to be used for disk encryption. Hence, you'd have to pass in a reference to the key-vault to be used (via variables). 
- In order to do that the user which executes terraform (basically, a service principal) has to have the permission to do so: 
  ```terraform
  key_permissions = [ "get", "create", "delete" ]
  ```

## What wil be provisioned

What the module creates is an encryption key inside the referenced key vault, a DES that uses that key to encrypt disks and an access policy that allows the DES to get that key.


[des]:https://docs.microsoft.com/en-us/azure/virtual-machines/disk-encryption
[key-vault]:https://docs.microsoft.com/en-us/azure/key-vault/general/basic-concepts