# LogicApp for (simple) CLI Automation

For some tedious yet simple automation tasks I wanted to have a pure-azure solution to regularly execute `az`-bash snippets. Turns out there is no (at least at the time of this writing) out-of-the-box offering that could do the trick.

Using LogicApps you can automate other services in Azure - so I came up with a solution where I use a LogicApp to fire up a Container Instance that executes a shell script (that I provide during provisioning). The service uses a consumption model and thus you only pay for the actual execution.

The setup itself is comprised of:
- you have to provide a user-managed identity which is
  1. used by the logic-app to connect towards container insides (this kind of integration has to be authenticated)
  2. used by the injected shell script to log into your subscription (using `az login --identity` - which is done for you, you don't have to define that pre-requisite step in your script)
- it uses `mcr.microsoft.com/azure-cli:latest` container image to provide an execution environment for your script
- Optional (only when you provide a respective value for `email_receivers_on_failure`) an alert together with an alert-group is defined which will triggere a notification in case the logic-app ran with failure.
- since that alerting might be not enough you can (optionally) integrate the logic-app also with an existing log-analytics workspace - by that you have way more alerting-possibilities

[//]: # (BEGIN_TF_DOCS)
## Example usage

The followin' example shows an exemplified use - this logic-app integrates with an existing log-analytics workspace:

```hcl
locals {
  application_id = "N/A"
  env            = "test"
  tags           = {
    created-by = "q442185"
    managed-by = "terraform"
  }
}

data "azurerm_client_config" "current" {}
data "azurerm_log_analytics_workspace" "this" {
  name                = "log-stefan-52518386cc33022de894"
  resource_group_name = "rg-stefan-common-test"
}
########################################################################################################################
# first we define a resource-group all components should be created in
########################################################################################################################
resource "azurerm_resource_group" "this" {
  location = "westeurope"
  name     = "rg-tf-udr-test"
  tags     = local.tags
}

########################################################################################################################
# LogicApp runs with a user managed identity ... let's create one using an already existing module
########################################################################################################################
module "picoptest_bomk8s_identity" {
  depends_on = [azurerm_resource_group.this]
  source     = "../../../managed_identity"

  identity_resource_group_name = azurerm_resource_group.this.name
  identity_name                = "id-tf-udr-user"
  identity_role_assignments    = [
    {
      scope = "/subscriptions/${data.azurerm_client_config.current.subscription_id}"
      role  = "Contributor"
    }
  ]
  application_id               = local.application_id
  env                          = local.env
  tags                         = local.tags
}

########################################################################################################################
# finally, define a logic-app that triggers a script every day (at 10 and 20 o'clock)
########################################################################################################################
module "cliautomator" {
  depends_on = [azurerm_resource_group.this]
  source     = "../.."

  application_id            = local.application_id
  env                       = local.env

  logic_app_name            = "la-tf-udr-test"
  resource_group_name       = azurerm_resource_group.this.name
  user_managed_identity_id  = module.picoptest_bomk8s_identity.managed_identity_id

  # let the script run daily at 10:00 and 20:00 (TZ=Berlin)
  script_schedule_frequency = "Day"
  script_schedule_interval  = "1"
  script_schedule_hours     = ["20", "10"]
  script_schedule_minutes   = ["0"]
  script_schedule_timezone  = "W. Europe Standard Time"

  # the script which has to be executed on a given schedule
  script_value = file("${path.module}/script.sh")

  # creates an alert (along with an alert-group) that notifies the given mails-recipients
  # in case the logic-app ran with failure
  email_receivers_on_failure = [ "stefan.schoeffmann@bmw.de" ]

  # I'd like to integrate the app also with our log-analytics workspaces so I can define an alert
  # based on the log-output of the script (which allows more fine-grain alerting)
  log_analytics_workspace_id  = data.azurerm_log_analytics_workspace.this.workspace_id
  log_analytics_workspace_key = data.azurerm_log_analytics_workspace.this.primary_shared_key
}
```
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.00 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 2.96.0 |

## Modules

No modules.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 2.96.0 |

## Resources

| Name | Type |
|------|------|
| [azurerm_container_group.cli_container_task](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_group) | resource |
| [azurerm_monitor_action_group.email_notification_group](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_action_group) | resource |
| [azurerm_monitor_metric_alert.logic_app_failure_alert](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_metric_alert) | resource |
| [azurerm_resource_group_template_deployment.aci_api_connection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_resource_group_template_deployment.cli_app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_logic_app_workflow.cli_app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/logic_app_workflow) | data source |
| [azurerm_resource_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/resource_group) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aci_connection_name"></a> [aci\_connection\_name](#input\_aci\_connection\_name) | The name of the ACI connection to be created | `string` | `"la-aci-connection"` | no |
| <a name="input_application_id"></a> [application\_id](#input\_application\_id) | (Required) BMW valid APPD id, e.g. APPD-12345. Pattern ^APPD-[0-9]{4,7}$ | `string` | n/a | yes |
| <a name="input_container_cpu"></a> [container\_cpu](#input\_container\_cpu) | The CPU the underlying container gets assigned | `string` | `"0.5"` | no |
| <a name="input_container_group_name"></a> [container\_group\_name](#input\_container\_group\_name) | Name of the container-group that is used to execute az-cli container | `string` | `"cg-az-cli-automation"` | no |
| <a name="input_container_image"></a> [container\_image](#input\_container\_image) | The image to be used by the container instance | `string` | `"mcr.microsoft.com/azure-cli:latest"` | no |
| <a name="input_container_memory"></a> [container\_memory](#input\_container\_memory) | The memory the underlying container gets assigned | `string` | `"0.5"` | no |
| <a name="input_container_name"></a> [container\_name](#input\_container\_name) | Name of the container | `string` | `"cli-task"` | no |
| <a name="input_container_osType"></a> [container\_osType](#input\_container\_osType) | The OS of the underlying container | `string` | `"Linux"` | no |
| <a name="input_container_restartPolicy"></a> [container\_restartPolicy](#input\_container\_restartPolicy) | Should the container get restarted in case of failure (default is 'Never') | `string` | `"Never"` | no |
| <a name="input_email_receivers_on_failure"></a> [email\_receivers\_on\_failure](#input\_email\_receivers\_on\_failure) | (Optional) A list of email-receivers that get notified via eMail in case the logic-app ran with failure | `list(string)` | `[]` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) Environment/Stage this resource is used in | `string` | n/a | yes |
| <a name="input_log_analytics_workspace_id"></a> [log\_analytics\_workspace\_id](#input\_log\_analytics\_workspace\_id) | (Optional) If you'd like to ingest the container-logs of the used ACI into your log-analytics workspace put in here the respective workspace ID | `string` | `null` | no |
| <a name="input_log_analytics_workspace_key"></a> [log\_analytics\_workspace\_key](#input\_log\_analytics\_workspace\_key) | (Optional) If you'd like to ingest the container-logs of the used ACI into your log-analytics workspace put in here the respective workspace Key | `string` | `null` | no |
| <a name="input_logic_app_name"></a> [logic\_app\_name](#input\_logic\_app\_name) | Name of the logicApp (default: la-az-cli-automation) | `string` | `"la-az-cli-automation"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | (Required) Name of the resource group the logic-app should be created in (won't be created by this module). | `string` | n/a | yes |
| <a name="input_script_schedule_frequency"></a> [script\_schedule\_frequency](#input\_script\_schedule\_frequency) | The frequency with which the logic app gets executed/triggered | `string` | `"Day"` | no |
| <a name="input_script_schedule_hours"></a> [script\_schedule\_hours](#input\_script\_schedule\_hours) | List of hours at which the logic app gets executed | `list(string)` | <pre>[<br>  "20"<br>]</pre> | no |
| <a name="input_script_schedule_interval"></a> [script\_schedule\_interval](#input\_script\_schedule\_interval) | Frequency-Interval the logic app gets executed/triggered | `string` | `"1"` | no |
| <a name="input_script_schedule_minutes"></a> [script\_schedule\_minutes](#input\_script\_schedule\_minutes) | List of minutes at which the logic app gets executed | `list(string)` | <pre>[<br>  "0"<br>]</pre> | no |
| <a name="input_script_schedule_timezone"></a> [script\_schedule\_timezone](#input\_script\_schedule\_timezone) | Timezone the logic app schedule should use | `string` | `"W. Europe Standard Time"` | no |
| <a name="input_script_value"></a> [script\_value](#input\_script\_value) | The script that gets executed by the container instance (on behalf of the user managed identity) | `string` | `"echo \"Plz provide a custom script!\""` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to be added to the provisioned resources (if applicable) | `map(string)` | `{}` | no |
| <a name="input_user_managed_identity_id"></a> [user\_managed\_identity\_id](#input\_user\_managed\_identity\_id) | (Required) ID of a user managed identity to be used by the logic-app. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_logic_app_id"></a> [logic\_app\_id](#output\_logic\_app\_id) | n/a |
| <a name="output_logic_app_name"></a> [logic\_app\_name](#output\_logic\_app\_name) | n/a |

[//]: # (END_TF_DOCS)

[connections]:https://docs.microsoft.com/en-us/azure/templates/microsoft.web/connections?tabs=json#template-format
[aws-ips]:https://aws.amazon.com/de/premiumsupport/knowledge-center/s3-find-ip-address-ranges/
[tf-provider-issue]:https://github.com/hashicorp/terraform-provider-azurerm/issues/1691
[arm-examples]:https://github.com/Azure/azure-quickstart-templates/blob/master/demos/arm-template-retrieve-azure-storage-access-keys/azuredeploy.json
