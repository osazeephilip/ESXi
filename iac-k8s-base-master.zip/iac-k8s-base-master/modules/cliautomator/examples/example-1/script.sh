cidrs=$(curl -s https://ip-ranges.amazonaws.com/ip-ranges.json | jq -r '.prefixes[] | select(.region=="eu-west-1") | select(.service=="S3") | .ip_prefix')

RG_NAME='Group-AMS-VNET-82'
RT_NAME='AzureGlobal'

for add in ${cidrs}; do
    timestamp=$(date +%s)
    exists=$(az network route-table route list --route-table-name ${RT_NAME} -g ${RG_NAME} -o json | jq -r "any(.[];.addressPrefix==\"${add}\")")
    if [[ "true" == "${exists}" ]];then
        echo "${add} already in route-table ${RT_NAME}/${RG_NAME}"
    else
        az network route-table route create --route-table-name ${RT_NAME} -g ${RG_NAME} --next-hop-type Internet --name S3-eu-west-1_${timestamp} --address-prefix ${add}
    fi
done;
