# Azure Diagnostics Settings

In this directory you'll find a bunch of modules all dedicated to _diagnostic settings_ definitions. Since the concrete diagnostics settings differ from service to service it would be tedious to manage 'em all by hand - hence we decided to generate these modules using a scripted approach. The baseline are the services we use(d) in our subscription at the time of this writing.

**The modules in here are not hand-written - use the generation scripts to update 'em**

## Scripting

1) `diagnostics.sh`: This script reads the resources in a (defined at the beginning of the script) subscription, filters 'em (since not all support diagnostics) and writes 'em to an output-file (called `typeMetricsAndLogs.txt`) using the followin' format:
   ```bash
    "microsoft.compute/virtualmachines",Metrics,    "AllMetrics"
    "microsoft.compute/virtualmachinescalesets",Metrics,    "AllMetrics"
    "microsoft.containerregistry/registries",Logs,    "ContainerRegistryRepositoryEvents"
    "microsoft.containerregistry/registries",Logs,    "ContainerRegistryLoginEvents"
    "microsoft.containerregistry/registries",Metrics,    "AllMetrics"
    "microsoft.containerservice/managedclusters",Logs,    "kube-apiserver"
    "microsoft.containerservice/managedclusters",Logs,    "kube-audit"
    "microsoft.containerservice/managedclusters",Logs,    "kube-audit-admin"
    "microsoft.containerservice/managedclusters",Logs,    "kube-controller-manager"
    "microsoft.containerservice/managedclusters",Logs,    "kube-scheduler"
    "microsoft.containerservice/managedclusters",Logs,    "cluster-autoscaler"
    "microsoft.containerservice/managedclusters",Logs,    "guard"
    "microsoft.containerservice/managedclusters",Metrics,    "AllMetrics"
    "microsoft.databricks/workspaces",Logs,    "dbfs"
    "microsoft.databricks/workspaces",Logs,    "clusters"
    "microsoft.databricks/workspaces",Logs,    "accounts"
    ...
    ```
2) `diagnosticsToTerraform.sh`: reads the file that was generated in the previous step, tokenizes each line in order to generate a terraform module per resource-type.<br/>
   Whenever you have changes on the diagnostics modules - change _this_ bash-script to change the generated `main.tf`-files<br/>
   **Notice:** Since Storage-Accounts define sub-resources it's even more fiddly to define diagnostics-integration - hence, for `microsoft_storage_storageaccounts` you have to manage the `main.tf` manually.

## Usage

You can use these modules directly to define a diagnostics integration by resource type:

```hcl
module "diagnostics_microsoft_container_registry" {
  source                                       = "../diagnostics/microsoft_containerregistry_registries"

  target_resource_id                           = var.acr_id                     # ACR resource to be integrated with ...
  log_analytics_workspace_id                   = var.log_analytics_workspace_id # ... this Log Analytics Workspace
  enable_log_ContainerRegistryLoginEvents      = true                           # dedicated flag per integration
  enable_log_ContainerRegistryRepositoryEvents = false
  enable_metric_AllMetrics                     = true
}
```

**Notice**: These modules are also integrated with our other terraform modules (so they are a dependency of them).


### Terraform caveats

All `log` and `metric` integrations define a dedicated `retention_policy`-block:
```hcl
  retention_policy {
    days    = 0
    enabled = false
  }
```
Although this doesn't have an effect on log-analytics integrations (should only affect storage-account integrations) we added this block explicitly to prevent terraform from constant re-provisionings of existing diagnostic integrations (see i.e. [here](https://github.com/terraform-providers/terraform-provider-azurerm/issues/5673) or [here](https://github.com/terraform-providers/terraform-provider-azurerm/issues/10388)). By adding the `retention_policy`-block explicitly terraform doesn't spot (unnecessary) differences between executions.
