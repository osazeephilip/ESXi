#!/bin/bash
set -e

input="typeMetricsAndLogs.txt"

types=()
lines=()
distinctTypes=()

# read all lines in the $input-file and split the entries at the delemiter
while  read -r line
do
  IFS=", \""
  read -a array <<< $line

  lines+=("$line")
  types+=("${array[0]}")
done < $input

for type in "${types[@]}"
do
    exists="0"

    for distinctType in ${distinctTypes[@]}; do
        if [ "$type" = "$distinctType" ]; then
            exists="1"
            break
        fi
    done

    if [ "$exists" = "0" ]; then
        distinctTypes+=($type)
    fi
done


for distinctType in "${distinctTypes[@]}"; do
    echo "---------------------------"
    distinctTypeNormalized="${distinctType//./_}"
    distinctTypeNormalized="${distinctTypeNormalized//\//_}"

    metrics=()
    logs=()

    # resolve metrics and logs for this type
    for line in "${lines[@]}"; do
        IFS=", \""
        read -a array <<< $line

        if [ "$distinctType" = "${array[0]}" ] && [ "Metrics" = "${array[1]}" ]
        then
          metrics+=("${array[2]}")
        fi

        if [ "$distinctType" = "${array[0]}" ] && [ "Logs" = "${array[1]}" ]
        then
          logs+=("${array[2]}")
        fi
    done

    # debug logging
    echo $distinctType
    echo "   Metrics"
    for metric in "${metrics[@]}"; do
      echo "      $metric"
    done
    echo "   Logs"
    for log in "${logs[@]}"; do
      echo "      $log"
    done

    # create Terraform for logAnalytics
    filename="${distinctTypeNormalized}/main.tf"
    mkdir -p ${distinctTypeNormalized}
    rm -f $filename
    touch $filename

    echo "variable \"target_resource_id\" {"                                             >> $filename
    echo "  type        = string"                                                        >> $filename
    echo "  description = \"Configure Diagnostic Settings for this resource.\""          >> $filename
    echo "}"                                                                             >> $filename
    echo ""                                                                              >> $filename
    echo "variable \"log_analytics_workspace_id\" {"                                     >> $filename
    echo "  type        = string"                                                        >> $filename
    echo "  description = \"Use this Log Analytics workspace.\""                         >> $filename
    echo "}"                                                                             >> $filename

    if [ "${#metrics[@]}" -ne "0" ]
    then
        for metric in "${metrics[@]}"
        do
            metricNormalized="${metric// /_}"
            metricNormalized="${metricNormalized//-/_}"
            echo ""                                                                      >> $filename
            echo "variable \"enable_metric_${metricNormalized}\"" {                      >> $filename
            echo "  type        = bool"                                                  >> $filename
            echo "  description = \"Enable diagnostics for metric '${metric}'.\""        >> $filename
            echo "  default     = true"                                                  >> $filename
            echo "}"                                                                     >> $filename
        done
    fi

    if [ "${#logs[@]}" -ne "0" ]
    then
        for log in "${logs[@]}"
        do
            logNormalized="${log// /_}"
            logNormalized="${logNormalized//-/_}"
            echo ""                                                                      >> $filename
            echo "variable \"enable_log_${logNormalized}\"" {                            >> $filename
            echo "  type        = bool"                                                  >> $filename
            echo "  description = \"Enable diagnostics for log '${log}'.\""              >> $filename
            echo "  default     = true"                                                  >> $filename
            echo "}"                                                                     >> $filename
        done
    fi


    echo ""                                                                              >> $filename
    echo "resource \"azurerm_monitor_diagnostic_setting\" \"$distinctTypeNormalized\" {" >> $filename
    echo "  name                       = \"logAnalytics\""                               >> $filename
    echo "  target_resource_id         = var.target_resource_id"                         >> $filename
    echo "  log_analytics_workspace_id = var.log_analytics_workspace_id"                 >> $filename
    echo ""                                                                              >> $filename

    if [ "${#metrics[@]}" -ne "0" ]
    then
        for metric in "${metrics[@]}"
        do
            metricNormalized="${metric// /_}"
            metricNormalized="${metricNormalized//-/_}"
            echo "  metric {"                                                            >> $filename
            echo "    category = \"$metric\""                                            >> $filename
            echo "    enabled  = var.enable_metric_${metricNormalized}"                  >> $filename
            echo "    retention_policy { "                                               >> $filename
            echo "      days    = 0"                                                     >> $filename
            echo "      enabled = false"                                                 >> $filename
            echo "    }"                                                                 >> $filename
            echo "  }"                                                                   >> $filename
        done
    fi

    if [ "${#logs[@]}" -ne "0" ]
    then
        for log in "${logs[@]}"
        do
            logNormalized="${log// /_}"
            logNormalized="${logNormalized//-/_}"
            echo "  log {"                                                               >> $filename
            echo "    category = \"$log\""                                               >> $filename
            echo "    enabled  = var.enable_log_${logNormalized}"                        >> $filename
            echo "    retention_policy { "                                               >> $filename
            echo "      days    = 0"                                                     >> $filename
            echo "      enabled = false"                                                 >> $filename
            echo "    }"                                                                 >> $filename
            echo "  }"                                                                   >> $filename
        done
    fi
    echo "}"                                                                             >> $filename
done
