#!/bin/bash
set -e

subscriptions="fca564c9-6b4e-4ece-87db-49cba4e01a9f"
fileOut="typeMetricsAndLogs.txt"

# delete file from previous executions
if [[ -z "$fileOut" ]]; then
  rm $fileOut
fi

echo "Resolving resource types within subscriptions '${subscriptions}'."
types=$(az graph query --subscriptions $subscriptions --graph-query "Resources | distinct type | order by type asc" | jq .data[].type)

declare typeMetricsAndLogs

for type in $types
do
    resourceId=$(az graph query --subscriptions $subscriptions --graph-query "where type =~ "$type" | project id" --first 1 | jq -r .data[].id)

    if [[ "${type}" = "\"microsoft.chaos/experiments\"" ]] || [[ "${type}" = "\"microsoft.portal/dashboards\"" ]] || [[ "${type}" = "\"microsoft.compute/snapshots\"" ]] || [[ "${type}" = "\"microsoft.resourcegraph/queries\"" ]]
    then
        echo "Skipping diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.compute/disks\"" ]
    then
        echo "Skipping diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.compute/diskencryptionsets\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.network/privatednszones\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.network/privatednszones/virtualnetworklinks\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.network/privateendpoints\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.compute/virtualmachines/extensions\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.insights/actiongroups\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.insights/activitylogalerts\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.managedidentity/userassignedidentities\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.network/networkintentpolicies\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.alertsmanagement/smartdetectoralertrules\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.insights/metricalerts\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.insights/scheduledqueryrules\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.network/networkwatchers\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.network/networkwatchers/flowlogs\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.network/routetables\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.operationalinsights/querypacks\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.operationsmanagement/solutions\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as not supported."
        continue
    fi

    if [ "${type}" = "\"microsoft.storage/storageaccounts\"" ]
    then
        echo "Skipping  diagnostic categories for resource type '${type}' as manually defined (has subCategories for blob/table/queue/file)."
        continue
    fi

    echo "Resolving diagnostic categories for resource type '${type}'."

    categoriesAll=$(az monitor diagnostic-settings categories list --resource "$resourceId" --query "value[].[categoryType, name]" -o json)

    isMetric=0
    isLogs=0

    IFS=$'\t\n' # do not break on whitespace i.e. "Disk Performance"

    # create a datastructure like type,[Metrics,Logs],CategoryName
    # this is probably pushing the limit regarding the worst parser I have written in any language
    for i in ${categoriesAll[@]}
    do
        # echo "$i"
        if [ $isMetric = 1 ]; then
            typeMetricsAndLogs+=("$type,Metrics,$i")
            isMetric=0
        fi

        if [ $isLogs = 1 ]; then
            typeMetricsAndLogs+=("$type,Logs,$i")
            isLogs=0
        fi

        if [ $i = "[" ]; then
            continue
        fi

        if [ $i = "]" ]; then
            continue
        fi

        if [ $i = "]," ]; then
            continue
        fi

        if [ $i = "    \"Metrics\"," ]; then
            isMetric=1
        fi

        if [ $i = "    \"Logs\"," ]; then
            isLogs=1
        fi
    done

    IFS=$defaultIFS # reset break in whitespace
done

IFS=$'\t\n' # do not break on whitespace i.e. "Disk Performance"

touch typeMetricsAndLogs.txt
echo "Exporting data to '$fileOut'."
for i in ${typeMetricsAndLogs[@]}; do
    echo $i >> $fileOut
done
