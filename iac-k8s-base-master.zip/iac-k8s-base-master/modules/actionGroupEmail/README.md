# Action Group f. Mail-Receiver

A very simple module which creates an ActionGroup that contains a configurable amount of email-receivers.

[//]: # (BEGIN_TF_DOCS)
## Requirements

No requirements.

## Modules

No modules.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_action_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_action_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_action_group_name"></a> [action\_group\_name](#input\_action\_group\_name) | The name of the Action Group. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_action_group_resource_group_name"></a> [action\_group\_resource\_group\_name](#input\_action\_group\_resource\_group\_name) | (Required) The name of the resource group in which to create the Action Group instance. | `string` | n/a | yes |
| <a name="input_action_group_short_name"></a> [action\_group\_short\_name](#input\_action\_group\_short\_name) | The short name of the action group. This will be used in SMS messages. | `string` | n/a | yes |
| <a name="input_application_id"></a> [application\_id](#input\_application\_id) | (Required) Application ID as documented in ConnectIT | `string` | n/a | yes |
| <a name="input_email_receivers"></a> [email\_receivers](#input\_email\_receivers) | A list of email-receivers that get notified via eMail | `list(string)` | `[]` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) Environment/Stage this resource is used in (default: test) | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to be added to the provisioned resources (if applicable) | `map(string)` | `{}` | no |

## Outputs

No outputs.

[//]: # (END_TF_DOCS)
