# Azure Key Vault

The purpose of this module is to provision a [dedicated key-vault][key-vault] to be used as secret store for the DES key (and other infrastructure components like app-gateway if applicable).

This module doesn't create a resource-group on its own but requires a reference to an existing one where it should be provisioned in.

Right now, it applies a hard-coded list of users that get rights (access policies) to manage key-vault content. This is my personal id ;) as well as the executing service account (in order to generate Keys etc. later on).

### Resulting Setup
- Key-Vault with soft-delete && purge protection _enabled_ (!)
  - **notice**: when used in conjunction with a Disk-Encryption-Set you _have to_ enable purge protection. Hence, this module defines enable-purge-protection as default values since it's meant to be used in combination with a DES.
- provides two predefined profiles for _Access policies_
  - read-access: meant to be used for MSI (for a detailed list of allowed actions per entry see `variables.tf`)
  - full-access: meant to be used for devops engineers and admins
- leverages service-endpoints and defines a CIDR/IP whitelist to restrict access (defaults to `160.46.252.0/25`, `104.209.111.0/24`, `104.209.113.0/24`)
- optionally (when provided as input var - see `keyvault_log_integration`) integrates with an existing LogAnalytics workspace

### Notice / be aware
The combination of [purge-protection and soft-delete][purge_protection] can be annoying during terraform tests. If activated, deleted key vaults (just as keys, secrets and certs) will be kept around until the purge-period is exceeded.

In addition, active purge-protection prevents explicit purging before the purge-period exceeds (terraform would report an error that it's not allowed to purge).

Until the purge-period exceeds you cannot re-use the name of the (soft) deleted key vault neither since it basically still exists (terraform would report an already-exists error).

Re-provisioning would basically just [recover the soft deleted vault][recover_soft_deleted_key_vaults] (this module explicitly grants the tf-user the `recover` right to allow that). You can also explicitly (for test-purposes) set the purge-period to its minimum value of 7 days to ease the pain a bit.

[key-vault]:https://docs.microsoft.com/en-us/azure/key-vault/general/basic-concepts
[csi]:https://azure.github.io/secrets-store-csi-driver-provider-azure/
[pod-identity]:https://azure.github.io/aad-pod-identity/#td-block-1
[recover_soft_deleted_key_vaults]:https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs#recover_soft_deleted_key_vaults
[purge_protection]:https://docs.microsoft.com/en-us/azure/key-vault/general/soft-delete-overview
