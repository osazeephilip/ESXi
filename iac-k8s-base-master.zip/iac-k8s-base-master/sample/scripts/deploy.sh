#!/bin/bash

# set -x

# Abort execution on any error
set -e

##########################################
#######         BEGIN: VARS         ######
##########################################
KUBE_CONFIG_FILE="./kubernetes/config_temp"
INIT_MANIFESTS_DIR="./kubernetes/init_manifests"
LB_SERVICE_NAME="dummy-loadbalancer-service"
LB_SERVICE_NAMESPACE="kube-system"

INGRESS_NAMESPACE="kube-devops"
INGRESS_HELM_VALUES_FILE="./apps/ingress/values.yaml"
##########################################
#######         END: VARS           ######
##########################################

function waitForExternalIP(){
    retries=30
    ip=""
    while [ -z $ip ] && [ $retries -gt 0 ]; do
        echo "Waiting for external IP - retries left: $retries"
        ip=$(kubectl --kubeconfig "${KUBE_CONFIG_FILE}" get svc $1 --namespace $2 --template="{{range .status.loadBalancer.ingress}}{{.ip}}{{end}}")
        retries=$((retries-1))
        [ -z "$ip" ] && sleep 10
    done
    if [ -z $ip ]; then
      echo "Could not obtain external IP for service."
      exit 1
    fi
    echo "Found external IP: $ip for AKS: $3  RESOURCE_GROUP: $4"
}

# Install YOUR project specific stuff...
function installBaseApps(){
    kubectl --kubeconfig "${KUBE_CONFIG_FILE}" create ns "$INGRESS_NAMESPACE" --dry-run=client -o yaml | kubectl --kubeconfig "${KUBE_CONFIG_FILE}" apply -f -

    # Add the ingress-nginx repository
    helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
    helm repo update

    # Use Helm to deploy an NGINX ingress controller
    helm upgrade --kubeconfig "${KUBE_CONFIG_FILE}" --install ingress ingress-nginx/ingress-nginx \
    --version 4.0.13 \
    -n "$INGRESS_NAMESPACE" \
    -f "$INGRESS_HELM_VALUES_FILE" \
    --wait \
    --timeout 6m0s
}

# Common
pushd common
  terraform init --upgrade
  terraform apply -auto-approve
popd

# AKS
pushd kubernetes
  terraform init --upgrade
  terraform apply -auto-approve
popd


# Loop through all resource groups... and their k8s cluster I've just created/refreshed
for f_rg in ${INIT_MANIFESTS_DIR}/*; do
    if [ -d "$f_rg" ]; then
        # ... and through their k8s cluster we've just created/refreshed
        for f_aks in ${f_rg}/*; do
            if [ -d "$f_aks" ]; then
                cluster_name=$(basename "$f_aks")
                rg_name=$(basename "$f_rg")
                echo "Start applying manifests to AKS: ${f_aks}  RESOURCE_GROUP: ${f_rg}"

                # First we are going to retrieve anonymous kube config with admin rights
                az aks get-credentials -n "${cluster_name}" -g "${rg_name}" --overwrite-existing --file "${KUBE_CONFIG_FILE}" --admin

                # # Now apply manifests
                for manifest in ${f_aks}/*.yaml ; do

                    # Storage Class / Cluster Role Binding
                    echo "Processing manifest: ${manifest}"
                    kubectl --kubeconfig "${KUBE_CONFIG_FILE}" apply -f $manifest
                done

                # Check if there is a service of type 'LoadBalancer' already available.
                svc_lb=$(kubectl --kubeconfig "${KUBE_CONFIG_FILE}" get svc --all-namespaces | awk '$3=="LoadBalancer" && $5!="<none>"  {print}' | wc -l)
                echo "Found services of type \"Loadbalancer\": ${svc_lb}"

                # If there is no service of type 'Loadbalancer' present, create a dummy instance in order to trigger creation of Azure LB 'kubernetes_intern'
                if [ $svc_lb -lt 1 ]; then
                  echo "Deploying temp service of type \"Loadbalancer\"..."
                  cat << EOF | kubectl --kubeconfig "${KUBE_CONFIG_FILE}" apply -f -
apiVersion: v1
kind: Service
metadata:
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-internal: "true"
  name: ${LB_SERVICE_NAME}
  namespace: ${LB_SERVICE_NAMESPACE}
spec:
  ports:
  - name: http
    port: 80
    protocol: TCP
    targetPort: 8080
  - name: https
    port: 443
    protocol: TCP
    targetPort: 8443
  selector:
    name: dummy
  sessionAffinity: None
  type: LoadBalancer
EOF

                  # As lb creation and ip assignment might take a while we have to wait
                  waitForExternalIP "${LB_SERVICE_NAME}" "${LB_SERVICE_NAMESPACE}" "${cluster_name}" "${rg_name}"

                  # Now lets remove dummy service as we should now have our external IP address which coulc be uses in app gateway later on
                  kubectl --kubeconfig "${KUBE_CONFIG_FILE}" --namespace "${LB_SERVICE_NAMESPACE}" delete svc "${LB_SERVICE_NAME}"
                fi

                # Install apps
                installBaseApps

                # Delete temp kube config file
                rm -rf "${KUBE_CONFIG_FILE}"
            fi
        done
    fi
done


# # App Gateway
# pushd app-gateway
#   terraform init --upgrade
#   terraform apply -auto-approve
# popd

set +x
set +e
