# TLS Certificates
How to create self signed key chain.

## App Gateway / AKS

Folllowing snippet shows how to generate self signed certs and how to import ca chain on client side

``` bash
# Root CA
openssl genrsa -out RootCA.key 4096
openssl req -new -x509 -days 360 -key RootCA.key -out RootCA.crt

# Intermediate CA
openssl genrsa -out IntermediateCA.key 4096
openssl req -new -key IntermediateCA.key -out IntermediateCA.csr
openssl x509 -req -days 1000 -in IntermediateCA.csr -CA RootCA.crt -CAkey RootCA.key -CAcreateserial -out IntermediateCA.crt



# Server Cert

# Define domain you want a certificate for
domain="aks-samplek8s-test-blue"
IP="10.11.76.241"


openssl req -new -newkey rsa:2048 -nodes -config <(<<END cat
[req]
prompt = no
distinguished_name = req_dn
req_extensions = req_ext
[req_dn]
commonName = "${domain}"
[req_ext]
subjectAltName = @san
[san]
IP.1 = ${IP}
DNS.1 = ${domain}
END
) -keyout "${domain}.key" > ${domain}.csr


# This creates tls certificate which should be used by your services
openssl x509 -req -days 1000 -in ${domain}.csr -CA IntermediateCA.crt -CAkey IntermediateCA.key -set_serial 0101  -out ${domain}.crt -sha1


# Combine intermediate and root ca into single file for distribution on clients (if wanted)
#cat RootCA.crt IntermediateCA.crt > chain.pem

# Create pxf format e.g. Azure
openssl pkcs12 -export -out certificate.pfx -inkey aks-samplek8s-test-blue.key -in aks-samplek8s-test-blue.crt


# On client side we have to import ca chain 
#cp chain.pem /etc/pki/ca-trust/source/anchors/
#update-ca-trust extract

``` 
