# Metric alert samples

# AKS metric Alerts

Basically there is already a set of recommended (by MSFT) alerts available that should act as solid starting point when it comes to AKS monitoring:

- https://docs.microsoft.com/en-us/azure/azure-monitor/containers/container-insights-metric-alerts
- https://docs.microsoft.com/en-us/azure/azure-monitor/containers/container-insights-metric-alerts#enable-with-a-resource-manager-template

Alerts definitions are provided as ARM templates in https://github.com/microsoft/Docker-Provider/tree/ci_dev/alerts/recommended_alerts_ARM and applied (in this example) with defaults (see [local copy](./recommended_alerts_ARM)). The `main.tf` file should give you an idea how to overwrite those defaults to suite your project-specific needs.

# PostgreSQL metric Alerts

An overview of available metrics can be found in the respective docs:
- [Monitor metrics on Azure Database for PostgreSQL - Flexible Server](https://docs.microsoft.com/en-us/azure/postgresql/flexible-server/concepts-monitoring)

|Metric|Metric Display Name|Unit|Description|
|---|---|---|---|
| active_connections | Active Connections | Count | The number of connections to your server. |
| backup_storage_used | Backup Storage Used | Bytes | Amount of backup storage used. This metric represents the sum of storage consumed by all the full database backups, differential backups, and log backups retained based on the backup retention period set for the server. The frequency of the backups is service managed. For geo-redundant storage, backup storage usage is twice that of the locally redundant storage. |
| connections_failed | Failed Connections | Count | Failed connections. |
| connections_succeeded | Succeeded Connections | Count | Succeeded connections. |
| cpu_credits_consumed | CPU Credits Consumed | Count | Number of credits used by the flexible server. Applicable to Burstable tier. |
| cpu_credits_remaining | CPU Credits Remaining | Count | Number of credits available to burst. Applicable to Burstable tier. |
| cpu_percent | CPU percent | Percent | Percentage of CPU in use. |
| disk_queue_depth | Disk Queue Depth | Count | Number of outstanding I/O operations to the data disk. |
| iops | IOPS | Count | Number of I/O operations to disk per second. |
| maximum_used_transactionIDs | Maximum Used Transaction IDs | Count | Maximum transaction ID in use. |
| memory_percent | Memory percent | Percent | Percentage of memory in use. |
| network_bytes_egress | Network Out | Bytes | Amount of outgoing network traffic. |
| network_bytes_ingress | Network In | Bytes | Amount of incoming network traffic. |
| read_iops | Read IOPS | Count | Number of data disk I/O read operations per second. |
| read_throughput | Read Throughput | Bytes | Bytes read per second from disk. |
| storage_free | Storage Free | Bytes | The amount of storage space available. |
| storage_percent | Storage percent | Percentage | Percent of storage space used. The storage used by the service may include the database files, transaction logs, and the server logs.|
| storage_used | Storage Used | Bytes | Percent of storage space used. The storage used by the service may include the database files, transaction logs, and the server logs. |
| txlogs_storage_used | Transaction Log Storage Used | Bytes | Amount of storage space used by the transaction logs. |
| write_throughput | Write Throughput | Bytes | Bytes written per second to disk. |
| write_iops | Write IOPS | Count | Number of data disk I/O write operations per second. |
[source](https://raw.githubusercontent.com/MicrosoftDocs/azure-docs/master/articles/postgresql/flexible-server/concepts-monitoring.md)

The definition of those metric-alerts using terraform is pretty straight forward (find a few more (but not exhaustive) examples in `main.tf`):
```
resource "azurerm_monitor_metric_alert" "postgresql_flexible_server_cpu_percent" {
  name                = "..."
  resource_group_name = "..."
  scopes              = [ postgresql_flexible_server.id ]
  frequency           = "PT1M"
  window_size         = "PT5M"
  auto_mitigate       = true
  severity            = 2

  criteria {
    metric_namespace = "microsoft.dbforpostgresql/flexibleservers"
    metric_name      = "cpu_percent"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 80
  }

  action { action_group_id = "..." }
}
```
