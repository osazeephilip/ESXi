# AKS via Terraform

## Context

This repository contains the PSBOM blueprint for AKS (and supporting infrastructure components). This repo is supposed to act as upstream repo for all AKS related topics of PSBOM sub-products. It defines an AKS setup that should meet 80% of all project requirements (regarding k8s on Azure).

The content of this repository is highly inspired by [NWS][nws] (BMW project that hosts/runs its own, custom AKS cluster) as well as [4wheels][4wheels] (the FG-24 AKS-offering where you just [order a pre-configured AKS][4wheels-order]). In addition, the efforts from our [fine folks of FG-4-I][back2code-repo] also played an important role - especially when it comes to security best practices.

Since we'd like to have full control over all our infrastructure components we also would like to manage our AKS cluster completely via Terraform/Jenkins/Helm ourselfs (instead of using 4wheels output as a starting point of our IoC journey).

## Usage

The most important part of this repo are of course its `modules` - to test things out and to demonstrate the suggested use it also contains `samples` (not meant to be re-usable as-is - but act as complete demo).

We highly recommend the usage of a remote state backend - so plz make sure you have [an Azure blob-store setup][remote-state-repo], so you can reference it during initialization.

The samples were tested using a [service principal](https://manage.azure.bmw.cloud/ ). You could also just use your `az`-login context for a quick experiment. Whatever way you use, **be aware** that for some parts of the script your user will need the `Owner` role to be able i.e. to assign roles to identities (i.e. `AcrPull`-role to fetch images into the AKS cluster).
```bash
az login                                              # everything would be executed on your behalf - careful with that
# ---- or -------
export ARM_CLIENT_ID=<SERVICE_PRINCIPAL_ID>           # in that case Terraform would use the
export ARM_CLIENT_SECRET=<SERVICE_PRINCIPAL_SECRET>   # ... credentials of the ENV-variables to
export ARM_SUBSCRIPTION_ID=<SUBSCRIPTION_ID>          # ... access Azure - put here the creds
export ARM_TENANT_ID=<TENANT_ID>                      # ... of your service-principal (used by i.e. Jenkins)
```

Specifically the `samples/common` in combination with `samples/kubernetes` would give so the followin' setup:

![Sample output that demonstrates the combined usage of most modules](./docs/images/setup.png)

There are more modules contained than these samples demonstrates - look into the `examples`-folder of each individual module to see some specific usages.

## Repo-Structure
In `modules` you'll find generic scripts that do the actual heavy lifting - all parameterized via variables. Parallel to that directory there are project specific folders which hold scripts that reference the modules and provide concrete values for all module-variables - defining an individual incarnation for a specific project (here i.e. for `sample`). You can find more details about this kind of [project structure in hashicorps blog post][project-structure].

```bash
.
├── README.md
├── modules                   # contains generic module definitions (stage/env independent)
│   │                         # 'main.tf' always contains the resource-definitions
│   │                         # 'output.tf' provide information to be used in subsequent resources (i.e. IDs or names)
│   │                         # 'variables.tf' defines the input-interface for this module
│   │
│   ├── acr                   # Container Registry to be used along with an AKS cluster
│   │   ├── main.tf           # An AKS cluster is supposed to have at least a link to one ACR where it can pull
│   │   ├── output.tf         # images from - having a dedicated ACR along with your AKS should minimize pull-periods
│   │   └── variables.tf      # The ACR is defined with a ServiceEndpoint and IP-whitelists (not possible via UI)
│   │
│   ├── des                   # Disk-Encryption-Set that is used to support encrypted persistent volumes
│   │   ├── main.tf
│   │   ├── output.tf
│   │   └── variables.tf
│   │
│   ├── diagnostics           # holds a bunch of diagnostics integration (which are resource-specific)
│   │   ├── microsoft_compute_virtualmachines           # diagnostics integrations are service-specific - we hold a bunch
│   │   │   ...                                         # of integrations in this directory (for most of the services we
│   │   ├── microsoft_operationalinsights_workspaces    # make use of). The contents are generated - so in order to add
│   │   └── microsoft_storage_storageaccounts           # further integrations plz reuse the generations scripts.
│   │
│   ├── key-vault             # meant to hold the DES-key as well as other secrets that are used in your subscription
│   │   ├── main.tf           # Having said that, it's nevertheless an independent module that can be used to create
│   │   ├── output.tf         # further Key-Vaults (for other purposes).
│   │   └── variables.tf
│   │
│   ├── kubernetes            # defines the k8s-cluster with optional support for log-analytics
│   │   ├── kubernetes.tf     # the actual definition of the AKS cluster
│   │   ├── output.tf
│   │   ├── policies.tf       # our AKS supports Azure policies and we're setting some defaults already up in here
│   │   ├── services.tf       # some services that ought to be installed on k8s later will have tight integrations
│   │   │                     # ... with azure components -> so we're generating here some YAMLs ready-to-be-applied
│   │   ├── templates         # this directory contains the template-YAMLs to be rendered after provisioning ...
│   │   │   ├── cluster-admin.yaml.tmpl   # ... renders an admin-cluster-role-binding
│   │   │   └── storage-classes.yaml.tmpl # ... renders storage-class definitions (that are linked to the DES)
│   │   ├── variables.tf
│   │   ├── versions.tf
│   │   └── zrs.feature.registration.sh   # for ZRS usage we have to register an additional features (hence this script)
│   │
│   ├── log-analytics         # we're provisioning a log-analytics workspace to ingest all logs/metrics of
│   │   ├── main.tf           # all the other modules provide a (mostly optional) integration with log-analytics.
│   │   ├── output.tf         # Since at the beginning of the migration it wasn't clear if _all_ projects would
│   │   └── variables.tf      # use log-analytics for _all_ their logging purposes the integration to the other
│   │                         # modules is optional (only when you activate diagnostics)
│   │
│   ├── logicAppITSM          # holds a logic-app that can be used to translate an Azure Alert to a
│   │   ├── README.md         # proper ITSM-Bridge request and subsequently calls the bridge
│   │   ├── armTemplate.tftpl # The app basically is defined using this ARM template
│   │   ├── examples          # contains a bunch of exemplified applications of this module
│   │   ├── main.tf
│   │   ├── output.tf
│   │   ├── variables.tf
│   │   └── versions.tf
│   │
│   ├── managed_identity      # our k8s cluster uses a (bunch of) user managed identity behind the scenes (no service
│   │   ├── main.tf           # principal anymore). Hence, using this module you can easily create a user
│   │   ├── output.tf         # managed identity (for all kinds of purposes - we need is mainly for AKS though)
│   │   └── variables.tf
│   │
│   ├── postgres-flexible-server  # contains a module to provision a postgres flexible server into an already prepared VNET
│   │   ├── exmaples          # contains a bunch of exemplified applications of this module
│   │   ├── main.tf           # this module supports custom as well as system-mgnt maintenance windows
│   │   ├── output.tf         # and optionally creates an initial set of DBs to be used after provisioning
│   │   └── varialbes.tf
│   │
│   └── vnet-preparation      # we have to integrate with a centrally provisioned VNET that is peered to the BMW on-prem
│       ├── main.tf           # network. Since that artifact isn't part of our TF-state we just adjust this VNET/Subnet
│       ├── variables.tf      # using a bash-script (integrated within TF - hence it'll be executed just once)
│       └── vnet.preparation.sh
│
└── sample                    # there the actual project-specific stuff is contained - here i.e. for 'sample'
    ├── common                # one part that define all cross-cutting components like ACR, Key-Vault or Log-Analytics
    │   ├── backend.tf        # uses remote state storage (azure blob storage)
    │   ├── main.tf           # instruments required modules to get things done
    │   ├── output.tf
    │   ├── provider.tf
    │   ├── variables.tf
    │   └── terraform.tfvars  # takes custom parameters
    │
    ├── kubernetes            # defines the k8s cluster
    │   ├── backend.tf        # uses remote state storage (azure blob storage)
    │   ├── main.tf           # this basically defines all variables for the 'kubernetes' module (size/amount pools etc.)
    │   ├── provider.tf
    │   ├── variables.tf
    │   └── terraform.tfvars  # takes custom parameters
    │
    ├── apps                  # holds basic and rather system related apps like ingress controller, metrics monitoring etc.
    │   ├── ingress           # contains a helm "values.yaml" only file which belongs to nginx ingress chart
    │   └── ...               # ...further apps according to your needs
    │
    ├── scripts               # holds scripts for automating lifecycles of common and aks
    │   └── deploy.sh         # idempotent script to maintain common, aks, and app-gateway
    │
    └── tls                   # location for TLS related artifacts (do not put secrets like keys in!)
        └── certificate.pfx   # TLS certificate (gitignored) which shall be dployed to app gateway (-> currently under construction, don't rely on it now)

```

### Usage

Copy or rename dir `sample` and parametrize `terraform.tfvars` in sub directory `common` and `kubernetes` in order to meet your requirements.

Since kubernetes uses/references the resources provisioned in `common` you should start there, so go into `common` first.

**Notice**: Some commands in that script require the `Owner`-role (i.e. in order to [assign the AcrPull role to your service principal][owner-role]).

Start comprehensive rollout
```bash
cd sample
bash scripts/deploy.sh
```
Now, be patient - provisioning a complete cluster may take ~20min ...

## What's included (as of now)

So, from a plain AKS point of view this cluster has feature parity with 4wheels (even exceeds it):

- **AKS**
  - uses several nodepools (you can define the number and equipment of those pools on a per-pool basis)
  - each pool spans 3 AZs
  - it uses `calico` (just like 4wheels - hence [you can leverage network policies][calico])
  - it uses `kubenet` (just [like 4wheels][kubenet])
  - Azure AD integration (just like ... you got it)
  - integrates with BMW network (as long as you deploy it into a BMW-provisioned VNET - like this setup does)
  - uses a user-managed identity to drive the cluster (no passwords, no manual credential rotation)
  - comes with Azure Policy AddOn installed and some pre-defined policies (that make sense in our setup - i.e. prevent the definition of publicly exposed services)
  - restricts access to the (public) control-plane via IP-whitelists (so the API server is basically accessible via the public internet, hence you have the means to restrict the access - that's a convenient setup when you have to work with external partners)<br/>
    _or_
  - can be provisioned in private mode (meaning the Control Plane won't be accessible over the public internet but only from within the BMW network - **beware**: _external partners will have to access the cluster via VDI, JumpHost etc._)
  - optionally allows to pick paid-SKU for AKS (gives you 99.99% availability of the control plane)
- **ACR**
  - that is integrated with AKS (so the kubelet user-identity owns the _AcrPull_ role)
  - network-access is restricted by IP-whitelists and service-endpoints (note that the latter is not possible (anymore?) to be defined/changed in the Portal - only via API)
- **KeyVault**
  - holds the RSA key that is used by the DES to encrypt PVs
  - defines a firewall so only BMW corp-network (via BMW proxy) network access is allowed (along with VNET integration)
- **DES**
  - this disk-encryption-set is used by k8s storage-classes to offer encrypted persistent volumes
  - the key used by this DES is stored in the provisioned key-vault
- **LogAnalytics Workspace**
  - nothing special about this so far - only that you can (optionally) integrate all the other modules to this workspace
  - also defines Container-Insight solution to be used with AKS
- **Managed Identity**
  - that is used to drive AKS
  - will be equipped with role-bindings to access/interact with all provisioned common services (i.e. Key-Vault, AKS control plane etc.)

[kubenet]:https://4wheels-docs.bmwgroup.net/azure/25_what_you_get/10_included_in_cluster/
[4wheels]:https://atc.bmwgroup.net/bitbucket/projects/SPBBUCKET/repos/4wheels-azure/browse
[4wheels-order]:https://manage.azure.bmw.cloud
[user-setup]:https://4wheels-docs.bmwgroup.net/azure/30_administration/20_user_administration/#bind-a-kubernetes-role-to-the-user
[calico]:https://4wheels-docs.bmwgroup.net/azure/40_examples/40_create_network_policy/
[nws]:https://atc.bmwgroup.net/bitbucket/projects/NWSTCMSAP/repos/wtcm-iac/browse
[nws-docu]:https://atc.bmwgroup.net/confluence/display/NWSTCMSAP/Infrastructure+as+Code+(IaC)+-+Terraform
[dashboard]:https://learn.hashicorp.com/tutorials/terraform/aks?in=terraform/kubernetes
[remote-state-repo]:https://atc.bmwgroup.net/bitbucket/users/q442185/repos/tf-remote-state-in-azure/browse
[owner-role]:https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles
[ad-groups]:https://atc.bmwgroup.net/confluence/display/INNOBOM/Managing+Roles+and+Access+Rights
[private-endpoints]:https://docs.microsoft.com/en-us/azure/private-link/disable-private-endpoint-network-policy
[dont-user-kubernetes-provider]:https://itnext.io/terraform-dont-use-kubernetes-provider-with-your-cluster-resource-d8ec5319d14a
[back2code-repo]:https://atc.bmwgroup.net/bitbucket/projects/BACK2CODE
[project-structure]:https://www.hashicorp.com/blog/structuring-hashicorp-terraform-configuration-for-production#separate-configurations-for-environments
